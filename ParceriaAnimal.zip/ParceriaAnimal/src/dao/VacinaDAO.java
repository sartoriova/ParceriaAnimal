package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.AnimalVacina;
import bean.Cliente;
import bean.CustoVacina;
import bean.FaturamentoVacina;
import bean.Vacina;

public class VacinaDAO {
	private Connection connection;
	
	public VacinaDAO() {
		connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Vacina v) {
		int inseriu = 0;
		String sql = "insert into vacina(nome, qtdMl, lab, data_fab) values (?,?,?,?);";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, v.getNome());
			stmt.setInt(2, v.getQtd_ml());
			stmt.setString(3, v.getLab());
			stmt.setString(4, v.getData_fab());
			inseriu = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Vacina> getLista(){
		Vacina v;
		String sql = "select * from vacina;";
		PreparedStatement stmt;
		try {
			ArrayList <Vacina> vacinas = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				v = new Vacina(rs.getString("nome"), rs.getInt("qtdMl"), rs.getString("lab"), rs.getString("data_fab"));
				vacinas.add(v);
			}
			rs.close();
			stmt.close();
			return vacinas;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean getVacina(String nome){
		boolean achou = false;
		String sql = "select * from vacina where nome like ?;";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, nome);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				achou = true;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e){
			e.printStackTrace();
		}
		return achou;
	}
	
	public int deletar(String nome) {
		int deletou = 0;
		String sql = "delete from vacina where nome like ?";
		String sql1 = "delete from toma where nomeVac = ?";
		PreparedStatement stmt;
		PreparedStatement stmt1;
		try {
			stmt = connection.prepareStatement(sql);
			stmt1 = connection.prepareStatement(sql1);
			stmt.setString(1, nome);
			stmt1.setString(1, nome);
			stmt1.executeUpdate();
			deletou = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return deletou;
	}
	
	public int alterar(String nome, Vacina v) {
		int alterou = 0;
		String sql = "update vacina set qtdMl = ?, lab = ?, data_fab = ? where nome like ?";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setInt(1, v.getQtd_ml());
			stmt.setString(2, v.getLab());
			stmt.setString(3, v.getData_fab());
			stmt.setString(4, nome);
			alterou = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return alterou;
	}
	
	public ArrayList <FaturamentoVacina> relatorio1(){
		FaturamentoVacina r1;
		String sql = "select v.nome as nomeVacina, sum(t.custo) as faturamento from toma as t join vacina as v on t.nomeVac = v.nome group by v.nome;";
		PreparedStatement stmt;
		try {
			ArrayList <FaturamentoVacina> resposta = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				r1 = new FaturamentoVacina(rs.getString("nomeVacina"), rs.getDouble("faturamento"));
				resposta.add(r1);
			}
			rs.close();
			stmt.close();
			return resposta;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList <CustoVacina> relatorio2(){
		CustoVacina r2;
		String sql = "select v.nome as nomeVacina, t.custo as custo from toma as t join vacina as v on t.nomeVac = v.nome group by nomeVacina;";
		PreparedStatement stmt;
		try {
			ArrayList <CustoVacina> resposta = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				r2 = new CustoVacina(rs.getString("nomeVacina"), rs.getDouble("custo"));
				resposta.add(r2);
			}
			rs.close();
			stmt.close();
			return resposta;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList <AnimalVacina> relatorio3(String cpfCli, String nomeAnimal){
		AnimalVacina r3;
		String sql = "select a.nomeCien as nomeAnimal, v.nome as nomeVacina from animal as a join toma as t on t.nomeCien = a.nomeCien join vacina as v on t.nomeVac = v.nome where a.cpfCli=? and a.nomeCien=?;";
		PreparedStatement stmt;
		try {
			ArrayList <AnimalVacina> resposta = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cpfCli);
			stmt.setString(2, nomeAnimal);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				r3 = new AnimalVacina(rs.getString("nomeAnimal"), rs.getString("nomeVacina"));
				resposta.add(r3);
			}
			rs.close();
			stmt.close();
			return resposta;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
}