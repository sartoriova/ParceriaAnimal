package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Animal;
import bean.Toma;
import bean.Vacina;

public class TomaDAO {
	private Connection connection;
	
	public TomaDAO() {
		connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Animal a, Vacina v, String dataApli, double custo){
		int inseriu = 0;
		String sql = "insert into toma(cpfCli, nomeCien, nomeVac, dataApli, custo) values (?,?,?,?,?);";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, a.getCpfCli());
			stmt.setString(2, a.getNomeCien());
			stmt.setString(3, v.getNome());
			stmt.setString(4, dataApli);
			stmt.setDouble(5, custo);
			inseriu = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Toma> getLista(){
		Toma t;
		ArrayList <Toma> vacinacoes = new ArrayList<>();
		String sql = "select * from toma;";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				t = new Toma();
				Animal a = new Animal();
				a.setCpfCli(rs.getString("cpfCli"));
				a.setNomeCien(rs.getString("nomeCien"));
				t.setAnimal(a);
				Vacina v = new Vacina();
				v.setNome(rs.getString("nomeVac"));
				t.setVacina(v);
				t = new Toma(a,v, rs.getString("dataApli"), rs.getDouble("custo"));
				vacinacoes.add(t);
			}
			rs.close();
			stmt.close();
			return vacinacoes;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean getToma(String cpfCli, String nomeCien, String nomeVac, String dataApli){
		boolean achou = false;
		String sql = "select * from toma where cpfCli = ? and nomeCien = ? and nomeVac = ? and dataApli = ?;";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cpfCli);
			stmt.setString(2, nomeCien);
			stmt.setString(3, nomeVac);
			stmt.setString(4, dataApli);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				achou = true;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e){
			e.printStackTrace();
		}
		return achou;
	}
	
	public int deletar(String cpfCli, String nomeCien, String nomeVac, String dataApli) {
		int deletou = 0;
		String sql = "delete from toma where cpfCli = ? and nomeCien = ? and nomeVac = ? and dataApli = ?;";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cpfCli);
			stmt.setString(2, nomeCien);
			stmt.setString(3, nomeVac);
			stmt.setString(4, dataApli);
			deletou = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return deletou;
	}
	
	public int alterar(String cpfCli, String nomeCien, String nomeVac, String dataApli, double custo) {
		int alterou = 0;
		String sql = "update toma set custo = ? where cpfCli = ? and nomeCien = ? and nomeVac = ? and dataApli = ?";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setDouble(1, custo);
			stmt.setString(2, cpfCli);
			stmt.setString(3, nomeCien);
			stmt.setString(4, nomeVac);
			stmt.setString(5, dataApli);
			alterou = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return alterou;
	}
}