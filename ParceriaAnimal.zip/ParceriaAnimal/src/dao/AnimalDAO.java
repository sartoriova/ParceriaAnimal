package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Animal;
import bean.Cliente;

public class AnimalDAO {
	private Connection connection;
	
	public AnimalDAO() {
		connection = new FabricaConexoes().getConnection();
	}
	
	public int inserir(Animal a) {
		int inseriu = 0;
		String sql = "insert into animal(cpfCli, nomeCien, especie, peso, sexo, class, data_nas, infoAd, alimentacaoPrin) values (?,?,?,?,?,?,?,?,?);";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, a.getCpfCli());
			stmt.setString(2, a.getNomeCien());
			stmt.setString(3, a.getEspecie());
			stmt.setDouble(4, a.getPeso());
			stmt.setString(5, a.getSexo());
			stmt.setString(6, a.getClassificacao());
			stmt.setString(7, a.getData_nas());
			stmt.setString(8, a.getInfoAd());
			stmt.setString(9, a.getAlimentacaoPrin());
			inseriu = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Animal> getLista(){
		Animal a;
		String sql = "select * from animal;";
		PreparedStatement stmt;
		try {
			ArrayList <Animal> animais = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				a = new Animal(rs.getString("cpfCli"), rs.getString("nomeCien"), rs.getString("especie"), rs.getDouble("peso"), rs.getString("sexo"), rs.getString("class"), rs.getString("data_nas"), rs.getString("infoAd"), rs.getString("alimentacaoPrin"));
				animais.add(a);
			}
			rs.close();
			stmt.close();
			return animais;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean getAnimal(String cpfCli, String nomeCien){
		boolean achou = false;
		String sql = "select * from animal where cpfCli = ? and nomeCien = ?;";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cpfCli);
			stmt.setString(2, nomeCien);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				achou = true;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e){
			e.printStackTrace();
		}
		return achou;
	}
	
	public int deletar(String cpfCli, String nomeCien) {
		int deletou = 0;
		String sql = "delete from animal where cpfCli = ? and nomeCien = ?;";
		String sql1 = "delete from toma where cpfCli = ? and nomeCien = ?;";
		PreparedStatement stmt;
		PreparedStatement stmt1;
		try {
			stmt = connection.prepareStatement(sql);
			stmt1 = connection.prepareStatement(sql1);
			stmt.setString(1, cpfCli);
			stmt.setString(2, nomeCien);
			stmt1.setString(1, cpfCli);
			stmt1.setString(2, nomeCien);
			stmt1.executeUpdate();
			deletou = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return deletou;
	}
	
	public int alterar(String cpfCli, String nomeCien, Animal a) {
		int alterou = 0;
		String sql = "update animal set especie = ?, peso = ?, sexo = ?, class = ?, data_nas = ?, infoAd = ?, alimentacaoPrin = ? where cpfCli = ? and nomeCien = ?";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, a.getEspecie());
			stmt.setDouble(2, a.getPeso());
			stmt.setString(3, a.getSexo());
			stmt.setString(4, a.getClassificacao());
			stmt.setString(5, a.getData_nas());
			stmt.setString(6, a.getInfoAd());
			stmt.setString(7, a.getAlimentacaoPrin());
			stmt.setString(8, a.getCpfCli());
			stmt.setString(9, a.getNomeCien());
			alterou = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return alterou;
	}
	
	
}
