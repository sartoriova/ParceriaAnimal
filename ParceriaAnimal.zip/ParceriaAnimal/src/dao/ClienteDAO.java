package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import bean.Cliente;
import bean.ClienteAnimal;
import bean.ClientesAnimais;
import bean.InfoCliente;

public class ClienteDAO {
	private Connection connection;
	
	public ClienteDAO() {
		connection = new FabricaConexoes().getConnection();
	}
		
	public int inserir(Cliente c) {
		int inseriu = 0;
		String sql = "insert into cliente(cpf, rg, primeiroNome, segundoNome, sobrenome, data_nas, fone, email, nCartao, log, n, bairro, complemento, cep, cidade, estado, pais) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, c.getCpf());
			stmt.setString(2, c.getRg());
			stmt.setString(3, c.getPrimeiroNome());
			stmt.setString(4, c.getSegundoNome());
			stmt.setString(5, c.getSobrenome());
			stmt.setString(6, c.getData_nas());
			stmt.setString(7, c.getFone());
			stmt.setString(8, c.getEmail());
			stmt.setString(9, c.getnCartao());
			stmt.setString(10, c.getLog());
			stmt.setInt(11, c.getN());
			stmt.setString(12, c.getBairro());
			stmt.setString(13, c.getComplemento());
			stmt.setString(14, c.getCep());
			stmt.setString(15, c.getCidade());
			stmt.setString(16, c.getEstado());
			stmt.setString(17, c.getPais());
			inseriu = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return inseriu;
	}
	
	public ArrayList<Cliente> getLista(){
		Cliente c;
		String sql = "select * from cliente;";
		PreparedStatement stmt;
		try {
			ArrayList <Cliente> clientes = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				c = new Cliente(rs.getString("cpf"), rs.getString("rg"), rs.getString("primeiroNome"), rs.getString("segundoNome"), rs.getString("sobrenome"), rs.getString("data_nas"), rs.getString("fone"), rs.getString("email"), rs.getString("nCartao"), rs.getString("log"), rs.getInt("n"), rs.getString("bairro"), rs.getString("complemento"), rs.getString("cep"), rs.getString("cidade"), rs.getString("estado"), rs.getString("pais"));
				clientes.add(c);
			}
			rs.close();
			stmt.close();
			return clientes;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean getCliente(String cpf){
		boolean achou = false;
		String sql = "select * from cliente where cpf = ?;";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cpf);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				achou = true;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e){
			e.printStackTrace();
		}
		return achou;
	}
	
	public boolean getRg(String rg){
		boolean achou = false;
		String sql = "select * from cliente where rg = ?;";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, rg);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				achou = true;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e){
			e.printStackTrace();
		}
		return achou;
	}
	
	public boolean getNCartao(String nCartao){
		boolean achou = false;
		String sql = "select * from cliente where nCartao = ?;";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, nCartao);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()) {
				achou = true;
			}
			rs.close();
			stmt.close();
		}catch (SQLException e){
			e.printStackTrace();
		}
		return achou;
	}
	
	public int deletar(String cpf) {
		int deletou = 0;
		String sql = "delete from cliente where cpf = ?";
		String sql1 = "delete from animal where cpfCli = ?";
		String sql2 = "delete from toma where cpfCli = ?";
		PreparedStatement stmt;
		PreparedStatement stmt1;
		PreparedStatement stmt2;
		try {
			stmt1 = connection.prepareStatement(sql1);
			stmt2 = connection.prepareStatement(sql2);
			stmt1.setString(1, cpf);
			stmt2.setString(1, cpf);
			stmt2.executeUpdate();
			stmt1.executeUpdate();
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cpf);
			deletou = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return deletou;
	}
	
	public int alterar(String cpf, Cliente c) {
		int alterou = 0;
		String sql = "update cliente set rg = ?, primeiroNome = ?, segundoNome = ?, sobrenome = ?, data_nas = ?, fone = ?, email = ?, nCartao = ?, log = ?, n = ?, bairro = ?, complemento = ?, cep = ?, cidade = ?, estado = ?, pais = ? where cpf = ?";
		PreparedStatement stmt;
		try {
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, c.getRg());
			stmt.setString(2, c.getPrimeiroNome());
			stmt.setString(3, c.getSegundoNome());
			stmt.setString(4, c.getSobrenome());
			stmt.setString(5, c.getData_nas());
			stmt.setString(6, c.getFone());
			stmt.setString(7, c.getEmail());
			stmt.setString(8, c.getnCartao());
			stmt.setString(9, c.getLog());
			stmt.setInt(10, c.getN());
			stmt.setString(11, c.getBairro());
			stmt.setString(12, c.getComplemento());
			stmt.setString(13, c.getCep());
			stmt.setString(14, c.getCidade());
			stmt.setString(15, c.getEstado());
			stmt.setString(16, c.getPais());
			stmt.setString(17, cpf);
			alterou = stmt.executeUpdate();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return alterou;
	}
	
	public ArrayList <ClienteAnimal> relatorio4(String cpfCli){
		ClienteAnimal c;
		String sql = "select c.primeiroNome as nomeCliente, a.nomeCien as nomeAnimal from cliente as c join animal as a on a.cpfCli = c.cpf where c.cpf=?;";
		PreparedStatement stmt;
		try {
			ArrayList <ClienteAnimal> resposta = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cpfCli);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				c = new ClienteAnimal(rs.getString("nomeCliente"), rs.getString("nomeAnimal"));
				resposta.add(c);
			}
			rs.close();
			stmt.close();
			return resposta;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList <ClientesAnimais> relatorio5(){
		ClientesAnimais c;
		String sql = "select c.primeiroNome as nomeCliente, a.nomeCien as nomeAnimal from cliente as c join animal as a on a.cpfCli = c.cpf;";
		PreparedStatement stmt;
		try {
			ArrayList <ClientesAnimais> resposta = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				c = new ClientesAnimais(rs.getString("nomeCliente"), rs.getString("nomeAnimal"));
				resposta.add(c);
			}
			rs.close();
			stmt.close();
			return resposta;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public ArrayList <InfoCliente> relatorio6(String cpfCli){
		InfoCliente u;
		String sql = "select a.nomeCien as nomeAnimal, a.infoAd as infoAd from animal as a join cliente as c on a.cpfCli = c.cpf where c.cpf = ?;";
		PreparedStatement stmt;
		try {
			ArrayList <InfoCliente> resposta = new ArrayList<>();
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, cpfCli);
			ResultSet rs = stmt.executeQuery();
			while(rs.next()) {
				u = new InfoCliente(rs.getString("nomeAnimal"), rs.getString("infoAd"));
				resposta.add(u);
			}
			rs.close();
			stmt.close();
			return resposta;
		}catch (SQLException e){
			e.printStackTrace();
		}
		return null;
	}
}
