package principal;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bean.Animal;
import bean.AnimalVacina;
import bean.Cliente;
import bean.ClienteAnimal;
import bean.ClientesAnimais;
import bean.CustoVacina;
import bean.FaturamentoVacina;
import bean.InfoCliente;
import bean.Toma;
import bean.Vacina;
import dao.AnimalDAO;
import dao.ClienteDAO;
import dao.TomaDAO;
import dao.VacinaDAO;

import javax.swing.JLayeredPane;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.ImageIcon;

public class MenuParceriaAnimal1 extends JFrame {

	private JPanel contentPane;
	private JLayeredPane layeredPane;
	private JMenuBar menuBar;
	private JPanel panel_1;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel;
	private JPanel panel_4;
	private JPanel panel_32;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JLabel lblNewLabel_9;
	private JLabel lblNewLabel_10;
	private JLabel lblNewLabel_11;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JLabel lblNewLabel_14;
	private JLabel lblNewLabel_15;
	private JLabel lblNewLabel_16;
	private JLabel lblNewLabel_17;
	private JLabel lblNewLabel_18;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JLabel lblNewLabel_19;
	private JLabel lblNewLabel_20;
	private JTextField textField_17;
	private JLabel lblNewLabel_21;
	private JTextField textField_18;
	private JLabel lblNewLabel_22;
	private JTextField textField_19;
	private JLabel lblNewLabel_23;
	private JTextField textField_20;
	private JLabel lblNewLabel_24;
	private JTextField textField_21;
	private JLabel lblNewLabel_25;
	private JTextField textField_22;
	private JLabel lblNewLabel_26;
	private JTextField textField_23;
	private JLabel lblNewLabel_27;
	private JTextField textField_24;
	private JLabel lblNewLabel_28;
	private JTextField textField_25;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel_29;
	private JLabel lblNewLabel_30;
	private JTextField textField_26;
	private JLabel lblNewLabel_31;
	private JTextField textField_27;
	private JLabel lblNewLabel_32;
	private JTextField textField_28;
	private JLabel lblNewLabel_33;
	private JTextField textField_29;
	private JButton btnNewButton_2;
	private JLabel lblNewLabel_34;
	private JLabel lblNewLabel_35;
	private JLabel lblNewLabel_36;
	private JLabel lblNewLabel_37;
	private JLabel lblNewLabel_38;
	private JLabel lblNewLabel_39;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField textField_33;
	private JTextField textField_34;
	private JButton btnNewButton_3;
	private JPanel panel_6;
	private JLabel lblNewLabel_41;
	private JLabel lblNewLabel_42;
	private JLabel lblNewLabel_43;
	private JLabel lblNewLabel_44;
	private JLabel lblNewLabel_45;
	private JLabel lblNewLabel_46;
	private JLabel lblNewLabel_47;
	private JLabel lblNewLabel_48;
	private JLabel lblNewLabel_49;
	private JLabel lblNewLabel_50;
	private JLabel lblNewLabel_51;
	private JTextField textField_36;
	private JTextField textField_37;
	private JTextField textField_38;
	private JTextField textField_39;
	private JTextField textField_40;
	private JTextField textField_41;
	private JTextField textField_42;
	private JTextField textField_43;
	private JTextField textField_44;
	private JLabel lblNewLabel_52;
	private JTextField textField_45;
	private JLabel lblNewLabel_53;
	private JTextField textField_46;
	private JLabel lblNewLabel_54;
	private JLabel lblNewLabel_55;
	private JLabel lblNewLabel_56;
	private JLabel lblNewLabel_57;
	private JLabel lblNewLabel_58;
	private JTextField textField_47;
	private JTextField textField_48;
	private JTextField textField_49;
	private JTextField textField_50;
	private JTextField textField_51;
	private JButton btnNewButton_4;
	private JTextField textField_35;
	private JPanel panel_7;
	private JPanel panel_8;
	private JLabel lblNewLabel_59;
	private JLabel lblNewLabel_60;
	private JTextField textField_52;
	private JLabel lblNewLabel_61;
	private JTextField textField_53;
	private JLabel lblNewLabel_62;
	private JTextField textField_54;
	private JLabel lblNewLabel_63;
	private JTextField textField_55;
	private JLabel lblNewLabel_64;
	private JTextField textField_56;
	private JLabel lblNewLabel_65;
	private JTextField textField_57;
	private JLabel lblNewLabel_66;
	private JTextField textField_58;
	private JLabel lblNewLabel_67;
	private JTextField textField_59;
	private JLabel lblNewLabel_68;
	private JTextField textField_60;
	private JButton btnNewButton_5;
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	private JPanel panel_10;
	private JLabel lblNewLabel_69;
	private JLabel lblNewLabel_70;
	private JTextField textField_61;
	private JLabel lblNewLabel_71;
	private JTextField textField_62;
	private JLabel lblNewLabel_72;
	private JTextField textField_63;
	private JLabel lblNewLabel_73;
	private JTextField textField_64;
	private JButton btnNewButton_6;
	private JPanel panel_11;
	private JPanel panel_13;
	private JLabel lblNewLabel_80;
	private JLabel lblNewLabel_81;
	private JLabel lblNewLabel_82;
	private JLabel lblNewLabel_83;
	private JLabel lblNewLabel_84;
	private JLabel lblNewLabel_85;
	private JTextField textField_70;
	private JTextField textField_71;
	private JTextField textField_72;
	private JTextField textField_73;
	private JTextField textField_74;
	private JButton btnNewButton_8;
	private JLabel lblNewLabel_87;
	private JPanel panel_14;
	private JPanel panel_15;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_86;
	private JTextField textField_75;
	private JButton btnDeletar;
	private JPanel panel_16;
	private JPanel panel_17;
	private JLabel lblNewLabel_105;
	private JLabel lblNewLabel_106;
	private JTextField textField_92;
	private JLabel lblNewLabel_107;
	private JTextField textField_93;
	private JButton btnNewButton_9;
	private JPanel panel_18;
	private JPanel panel_19;
	private JLabel lblNewLabel_115;
	private JLabel lblNewLabel_116;
	private JTextField textField_101;
	private JButton btnNewButton_10;
	private JPanel panel_20;
	private JPanel panel_21;
	private JLabel lblNewLabel_120;
	private JLabel lblNewLabel_121;
	private JLabel lblNewLabel_122;
	private JLabel lblNewLabel_123;
	private JLabel lblNewLabel_124;
	private JTextField textField_105;
	private JTextField textField_106;
	private JTextField textField_107;
	private JTextField textField_108;
	private JButton btnNewButton_11;
	private JPanel panel_12;
	private JPanel panel_22;
	private JLabel lblNewLabel_74;
	private JPanel panel_23;
	private JLabel lblNewLabel_75;
	private JTable table_1;
	private JScrollPane scrollPane_3;
	private JPanel panel_24;
	private JLabel lblNewLabel_76;
	private JTable table_2;
	private JTable table_3;
	private JScrollPane scrollPane_4;
	private JPanel panel_25;
	private JLabel lblNewLabel_77;
	private JPanel panel_26;
	private JPanel panel_28;
	private JLabel lblNewLabel_79;
	private JPanel panel_27;
	private JLabel lblNewLabel_78;
	private JPanel panel_29;
	private JLabel lblNewLabel_126;
	private JPanel panel_30;
	private JLabel lblNewLabel_127;
	private JTextField textField_65;
	private JTextField textField_66;
	private JTextField textField_67;
	private JLabel lblNewLabel_90;
	private JTable table_6;
	private JTable table_7;
	private JScrollPane scrollPane_8;
	private JTextField textField_68;
	private JLabel lblNewLabel_91;
	private JButton btnNewButton_16;
	private JTextField textField_69;
	private JTextField textField_76;
	private JTextField textField_77;
	private JTextField textField_78;
	private JLabel lblNewLabel_92;
	private JLabel lblNewLabel_93;
	private JLabel lblNewLabel_94;
	private JLabel lblNewLabel_95;
	private JTable table_4;
	private JButton btnNewButton_18;
	private JScrollPane scrollPane_5;
	private JTable table_8;
	private JScrollPane scrollPane_9;
	private JMenuItem mntmNewMenuItem_21;
	private JMenuItem mntmNewMenuItem_22;
	private JMenuItem mntmNewMenuItem_23;
	private JMenuItem mntmNewMenuItem_24;
	private JMenu mnNewMenu_3;
	private JMenuItem mntmNewMenuItem;
	private JMenuItem mntmNewMenuItem_1;
	private JMenuItem mntmNewMenuItem_2;
	private JMenuItem mntmNewMenuItem_3;
	private JMenuItem mntmNewMenuItem_25;
	private JMenuItem mntmNewMenuItem_26;
	private JMenuItem mntmNewMenuItem_27;
	private JMenuItem mntmNewMenuItem_28;
	private JPanel panel_33;
	private JLabel lblNewLabel_97;
	private JLabel lblNewLabel_98;
	private JLabel lblNewLabel_99;
	private JLabel lblNewLabel_100;
	private JLabel lblNewLabel_101;
	private JLabel lblNewLabel_102;
	private JTextField textField_79;
	private JTextField textField_80;
	private JTextField textField_81;
	private JTextField textField_82;
	private JTextField textField_83;
	private JButton btnNewButton_20;
	private JMenu mnNewMenu_1;
	private JMenuItem mntmNewMenuItem_4;
	private JMenuItem mntmNewMenuItem_5;
	private JMenuItem mntmNewMenuItem_6;
	private JMenuItem mntmNewMenuItem_7;
	private JMenu mnNewMenu;
	private JMenuItem mntmNewMenuItem_8;
	private JTable table;
	private JTable table_5;
	private JPanel panel_34;
	private JTable table_9;
	private JPanel panel_35;
	private JTable table_10;
	private JScrollPane scrollPane_11;
	private JMenuItem mntmNewMenuItem_10;
	private JMenuItem mntmNewMenuItem_11;
	private JPanel panel_36;
	private JTable table_11;
	private JScrollPane scrollPane_12;
	private JPanel panel_37;
	private JMenuItem mntmNewMenuItem_16;
	private JTable table_12;
	private JScrollPane scrollPane_13;
	private JTextField textField_84;
	private JTextField textField_85;
	private JTextField textField_86;
	private JTable table_13;
	private JTextField textField_87;
	private JPanel panel_38;
	private JTable table_14;
	private JPanel panel_39;
	private JLabel lblNewLabel_113;
	private JLabel lblNewLabel_114;
	private JLabel lblNewLabel_117;
	private JLabel lblNewLabel_118;
	private JLabel lblNewLabel_119;
	private JLabel lblNewLabel_125;
	private JLabel lblNewLabel_128;
	private JLabel lblNewLabel_129;
	private JLabel lblNewLabel_130;
	private JLabel lblNewLabel_131;
	private JLabel lblNewLabel_132;
	private JLabel lblNewLabel_133;
	private JLabel lblNewLabel_134;
	private JLabel lblNewLabel_135;
	private JLabel lblNewLabel_136;
	private JLabel lblNewLabel_137;
	private JLabel lblNewLabel_138;
	private JLabel lblNewLabel_139;
	private JLabel lblNewLabel_140;
	private JLabel lblNewLabel_141;
	private JLabel lblNewLabel_142;
	private JLabel lblNewLabel_143;
	private JLabel lblNewLabel_144;
	private JLabel lblNewLabel_145;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuParceriaAnimal1 frame = new MenuParceriaAnimal1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void Switch_Screen(JPanel p) {
		layeredPane.removeAll();
		layeredPane.add(p);
		layeredPane.repaint();
		layeredPane.revalidate();
	}

	/**
	 * Create the frame.
	 */
	public MenuParceriaAnimal1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 531, 318);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu_2 = new JMenu("Cadastro");
		mnNewMenu_2.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/cadastro w.png")));
		menuBar.add(mnNewMenu_2);
		
		mntmNewMenuItem_21 = new JMenuItem("1. Cadastrar Cliente");
		mntmNewMenuItem_21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_1);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_21);
		
		mntmNewMenuItem_22 = new JMenuItem("2. Cadastrar Animal");
		mntmNewMenuItem_22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_2);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_22);
		
		mntmNewMenuItem_23 = new JMenuItem("3. Cadastrar Vacina");
		mntmNewMenuItem_23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_3);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_23);
		
		mntmNewMenuItem_24 = new JMenuItem("4. Cadastrar Vacinação");
		mntmNewMenuItem_24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_4);
			}
		});
		mnNewMenu_2.add(mntmNewMenuItem_24);
		
		mnNewMenu_3 = new JMenu("Mostrar");
		mnNewMenu_3.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/mostrar.png")));
		menuBar.add(mnNewMenu_3);
		
		mntmNewMenuItem = new JMenuItem("1. Todos os clientes cadastrados");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_28);
				DefaultTableModel model = (DefaultTableModel) table_5.getModel();
				model.setRowCount(0);
				ClienteDAO cdao = new ClienteDAO();
				ArrayList <Cliente> clientes = cdao.getLista();
				if(clientes.isEmpty()) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Não há clientes cadastrados!","Alert",JOptionPane.WARNING_MESSAGE);
				}
				for(Cliente c : clientes) {
					model.addRow(new Object[] {c.getCpf(), c.getRg(), c.getPrimeiroNome(), c.getSegundoNome(), c.getSobrenome(), c.getData_nas(), c.getFone(), c.getEmail(), c.getnCartao(), c.getLog(), c.getN(), c.getBairro(), c.getComplemento(), c.getCep(), c.getCidade(), c.getEstado(), c.getPais()});
				}
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem);
		
		mntmNewMenuItem_1 = new JMenuItem("2. Um cliente cadastrado");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_22);
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.setRowCount(0);
				textField_68.setText("");
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_1);
		
		mntmNewMenuItem_2 = new JMenuItem("3. Todos os animais cadastrados");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_27);
				DefaultTableModel model = (DefaultTableModel) table_6.getModel();
				model.setRowCount(0);
				AnimalDAO adao = new AnimalDAO();
				ArrayList <Animal> animais = adao.getLista();
				for(Animal a : animais) {
					model.addRow(new Object[] {a.getCpfCli(), a.getNomeCien(), a.getEspecie(), a.getPeso(), a.getSexo(), a.getClassificacao(), a.getData_nas(), a.getInfoAd(), a.getAlimentacaoPrin()});
				}
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_2);
		
		mntmNewMenuItem_3 = new JMenuItem("4. Um animal cadastrado");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_23);
				DefaultTableModel model = (DefaultTableModel) table_1.getModel();
				model.setRowCount(0);
				textField_65.setText("");
				textField_66.setText("");
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_3);
		
		mntmNewMenuItem_25 = new JMenuItem("5. Todas as vacinas cadastradas");
		mntmNewMenuItem_25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_29);
				DefaultTableModel model = (DefaultTableModel) table_7.getModel();
				model.setRowCount(0);
				VacinaDAO vdao = new VacinaDAO();
				ArrayList <Vacina> vacinas = vdao.getLista();
				for(Vacina v : vacinas) {
					model.addRow(new Object[] {v.getNome(), v.getQtd_ml(), v.getLab(), v.getData_fab()});
				}
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_25);
		
		mntmNewMenuItem_26 = new JMenuItem("6. Uma vacina cadastrada");
		mntmNewMenuItem_26.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_24);
				DefaultTableModel model = (DefaultTableModel) table_3.getModel();
				model.setRowCount(0);
				textField_67.setText("");
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_26);
		
		mntmNewMenuItem_27 = new JMenuItem("7. Todas as vacinações cadastradas");
		mntmNewMenuItem_27.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_30);
				DefaultTableModel model = (DefaultTableModel) table_8.getModel();
				model.setRowCount(0);
				TomaDAO tdao = new TomaDAO();
				ArrayList <Toma> vacinacoes = tdao.getLista();
				for(Toma t : vacinacoes) {
					model.addRow(new Object[] {t.getAnimal().getCpfCli(), t.getAnimal().getNomeCien(), t.getVacina().getNome(), t.getDataApli(), t.getCusto()});
				}
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_27);
		
		mntmNewMenuItem_28 = new JMenuItem("8. Uma vacinação cadastrada");
		mntmNewMenuItem_28.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_25);
				DefaultTableModel model = (DefaultTableModel) table_4.getModel();
				model.setRowCount(0);
				textField_69.setText("");
				textField_76.setText("");
				textField_77.setText("");
				textField_78.setText("");
			}
		});
		mnNewMenu_3.add(mntmNewMenuItem_28);
		
		JMenu mnNewMenu_4 = new JMenu("Alteração");
		mnNewMenu_4.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/alterar.png")));
		menuBar.add(mnNewMenu_4);
		
		JMenuItem mntmNewMenuItem_12 = new JMenuItem("1. Alterar Cliente");
		mntmNewMenuItem_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_6);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_12);
		
		JMenuItem mntmNewMenuItem_13 = new JMenuItem("2. Alterar Animal");
		mntmNewMenuItem_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_8);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_13);
		
		JMenuItem mntmNewMenuItem_14 = new JMenuItem("3. Alterar Vacina");
		mntmNewMenuItem_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_10);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_14);
		
		JMenuItem mntmNewMenuItem_15 = new JMenuItem("4. Alterar Vacinação");
		mntmNewMenuItem_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_13);
			}
		});
		mnNewMenu_4.add(mntmNewMenuItem_15);
		
		mnNewMenu_1 = new JMenu("Deletar");
		mnNewMenu_1.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/deletar.png")));
		menuBar.add(mnNewMenu_1);
		
		mntmNewMenuItem_4 = new JMenuItem("1. Cliente");
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_15);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_4);
		
		mntmNewMenuItem_5 = new JMenuItem("2. Animal");
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_17);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_5);
		
		mntmNewMenuItem_6 = new JMenuItem("3. Vacina");
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_18);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_6);
		
		mntmNewMenuItem_7 = new JMenuItem("4. Vacinação");
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_21);
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_7);
		
		mnNewMenu = new JMenu("Relatórios");
		mnNewMenu.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/icons8-lista-restrita-50.png")));
		mnNewMenu.setBackground(Color.RED);
		menuBar.add(mnNewMenu);
		
		mntmNewMenuItem_8 = new JMenuItem("1. Consultar o faturamento total de cada vacina");
		mntmNewMenuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_34);
				VacinaDAO vdao = new VacinaDAO();
				ArrayList <FaturamentoVacina> resposta = vdao.relatorio1();
				DefaultTableModel model = (DefaultTableModel) table_9.getModel();
				model.setRowCount(0);
				for(FaturamentoVacina r1 : resposta) {
					model.addRow(new Object[] {r1.getNomeVac(), r1.getFaturamento()});
				}
			}
		});
		mnNewMenu.add(mntmNewMenuItem_8);
		
		JMenuItem mntmNewMenuItem_9 = new JMenuItem("2. Consultar o preço de cada vacina");
		mntmNewMenuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_39);
				VacinaDAO vdao = new VacinaDAO();
				ArrayList <CustoVacina> resposta = vdao.relatorio2();
				DefaultTableModel model = (DefaultTableModel) table_14.getModel();
				model.setRowCount(0);
				for(CustoVacina r2 : resposta) {
					model.addRow(new Object[] {r2.getNomeVac(), r2.getCusto()});
				}
			}
		});
		mnNewMenu.add(mntmNewMenuItem_9);
		
		mntmNewMenuItem_10 = new JMenuItem("3. Consultar as vacinas aplicadas em um determinado animal");
		mntmNewMenuItem_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_35);
				DefaultTableModel model = (DefaultTableModel) table_10.getModel();
				model.setRowCount(0);
				textField_85.setText("");
				textField_86.setText("");
			}
		});
		mnNewMenu.add(mntmNewMenuItem_10);
		
		mntmNewMenuItem_11 = new JMenuItem("4. Consultar os animais de um determinado cliente");
		mntmNewMenuItem_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_36);
				DefaultTableModel model = (DefaultTableModel) table_11.getModel();
				model.setRowCount(0);
				textField_84.setText("");
			}
		});
		mnNewMenu.add(mntmNewMenuItem_11);
		
		mntmNewMenuItem_16 = new JMenuItem("5. Consultar os clientes e seus animais");
		mntmNewMenuItem_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_37);
				ClienteDAO cdao = new ClienteDAO();
				ArrayList <ClientesAnimais> resposta = cdao.relatorio5();
				DefaultTableModel model = (DefaultTableModel) table_12.getModel();
				model.setRowCount(0);
				for(ClientesAnimais r5 : resposta) {
					model.addRow(new Object[] {r5.getNomeCliente(), r5.getNomeAnimal()});
				}
			}
		});
		mnNewMenu.add(mntmNewMenuItem_16);
		
		JMenuItem mntmNewMenuItem_17 = new JMenuItem("6. Consultar a informação adicional dos animais de um determinado cliente");
		mntmNewMenuItem_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_Screen(panel_38);
				DefaultTableModel model = (DefaultTableModel) table_13.getModel();
				model.setRowCount(0);
				textField_87.setText("");
			}
		});
		mnNewMenu.add(mntmNewMenuItem_17);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
	    layeredPane = new JLayeredPane();
		layeredPane.setBounds(0, 0, 521, 265);
		contentPane.add(layeredPane);
		
		panel_36 = new JPanel();
		panel_36.setBackground(Color.PINK);
		panel_36.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_36);
		panel_36.setLayout(null);
		
		scrollPane_12 = new JScrollPane();
		scrollPane_12.setBounds(10, 10, 253, 179);
		panel_36.add(scrollPane_12);
		
		table_11 = new JTable();
		scrollPane_12.setViewportView(table_11);
		table_11.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"1\u00B0 Nome do Cliente", "Nome do Animal"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnNewButton_13 = new JButton("Mostrar");
		btnNewButton_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table_11.getModel();
				model.setRowCount(0);
				String cpfCli = textField_84.getText();
				ClienteDAO cdao = new ClienteDAO();
				boolean achou = cdao.getCliente(cpfCli);
				if(achou) {
					ArrayList <ClienteAnimal> resposta = cdao.relatorio4(cpfCli);
					for(ClienteAnimal r4 : resposta) {
						model.addRow(new Object[] {r4.getNomeCliente(), r4.getNomeAnimal()});
					}
				}else {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Este cliente não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_13.setBounds(298, 196, 118, 23);
		panel_36.add(btnNewButton_13);
		
		textField_84 = new JTextField();
		textField_84.setBounds(382, 69, 86, 20);
		panel_36.add(textField_84);
		textField_84.setColumns(10);
		
		JLabel lblNewLabel_96 = new JLabel("CPF do Cliente:");
		lblNewLabel_96.setBounds(273, 72, 99, 14);
		panel_36.add(lblNewLabel_96);
		
		lblNewLabel_137 = new JLabel("");
		lblNewLabel_137.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_137.setBounds(0, 0, 521, 265);
		panel_36.add(lblNewLabel_137);
		
		panel_35 = new JPanel();
		panel_35.setBackground(Color.CYAN);
		panel_35.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_35);
		panel_35.setLayout(null);
		
		scrollPane_11 = new JScrollPane();
		scrollPane_11.setBounds(16, 10, 254, 175);
		panel_35.add(scrollPane_11);
		
		table_10 = new JTable();
		scrollPane_11.setViewportView(table_10);
		table_10.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome do Animal", "Nome da Vacina "
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_103 = new JLabel("CPF do Cliente:");
		lblNewLabel_103.setBounds(280, 67, 101, 14);
		panel_35.add(lblNewLabel_103);
		
		JLabel lblNewLabel_104 = new JLabel("Nome do Animal:");
		lblNewLabel_104.setBounds(295, 92, 106, 14);
		panel_35.add(lblNewLabel_104);
		
		textField_85 = new JTextField();
		textField_85.setBounds(407, 65, 86, 20);
		panel_35.add(textField_85);
		textField_85.setColumns(10);
		
		textField_86 = new JTextField();
		textField_86.setBounds(407, 90, 86, 20);
		panel_35.add(textField_86);
		textField_86.setColumns(10);
		
		JButton btnNewButton_14 = new JButton("Mostrar");
		btnNewButton_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table_10.getModel();
				model.setRowCount(0);
				String cpfCli = textField_85.getText();
				String nomeAnimal = textField_86.getText();
				AnimalDAO adao = new AnimalDAO();
				boolean achou = adao.getAnimal(cpfCli, nomeAnimal);
				if(achou) {
					VacinaDAO vdao = new VacinaDAO();
					ArrayList <AnimalVacina> resposta = vdao.relatorio3(cpfCli, nomeAnimal);
					for(AnimalVacina r3 : resposta) {
						model.addRow(new Object[] {r3.getNomeAnimal(), r3.getNomeVacina()});
					}
				}else {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Este animal não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_14.setBounds(322, 206, 89, 23);
		panel_35.add(btnNewButton_14);
		
		lblNewLabel_143 = new JLabel("");
		lblNewLabel_143.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_143.setBounds(0, 0, 521, 265);
		panel_35.add(lblNewLabel_143);
		
		panel_38 = new JPanel();
		panel_38.setBackground(Color.MAGENTA);
		panel_38.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_38);
		panel_38.setLayout(null);
		
		JScrollPane scrollPane_14 = new JScrollPane();
		scrollPane_14.setBounds(10, 10, 266, 178);
		panel_38.add(scrollPane_14);
		
		table_13 = new JTable();
		scrollPane_14.setViewportView(table_13);
		table_13.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome Animal", "Informa\u00E7\u00E3o adicional"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel_108 = new JLabel("CPF do Cliente:");
		lblNewLabel_108.setBounds(302, 63, 95, 14);
		panel_38.add(lblNewLabel_108);
		
		textField_87 = new JTextField();
		textField_87.setBounds(396, 61, 67, 20);
		panel_38.add(textField_87);
		textField_87.setColumns(10);
		
		JButton btnNewButton_15 = new JButton("Mostrar");
		btnNewButton_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table_13.getModel();
				model.setRowCount(0);
				String cpfCli = textField_87.getText();
				ClienteDAO cdao = new ClienteDAO();
				boolean achou = cdao.getCliente(cpfCli);
				if(achou) {
					ArrayList <InfoCliente> resposta = cdao.relatorio6(cpfCli);
					for(InfoCliente r6 : resposta) {
						model.addRow(new Object[] {r6.getNomeAnimal(), r6.getInfoAd()});
					}
				}else {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Este cliente não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_15.setBounds(359, 218, 89, 23);
		panel_38.add(btnNewButton_15);
		
		lblNewLabel_144 = new JLabel("");
		lblNewLabel_144.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_144.setBounds(0, 0, 521, 265);
		panel_38.add(lblNewLabel_144);
		
		
		panel_39 = new JPanel();
		panel_39.setBackground(Color.GREEN);
		panel_39.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_39);
		panel_39.setLayout(null);
		
		JScrollPane scrollPane_15 = new JScrollPane();
		scrollPane_15.setBounds(10, 20, 249, 140);
		panel_39.add(scrollPane_15);
		
		table_14 = new JTable();
		scrollPane_15.setViewportView(table_14);
		table_14.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome da Vacina", "Pre\u00E7o"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		lblNewLabel_140 = new JLabel("");
		lblNewLabel_140.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_140.setBounds(0, 0, 521, 265);
		panel_39.add(lblNewLabel_140);
		
		panel_37 = new JPanel();
		panel_37.setBackground(Color.YELLOW);
		panel_37.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_37);
		panel_37.setLayout(null);
		
		scrollPane_13 = new JScrollPane();
		scrollPane_13.setBounds(10, 27, 255, 130);
		panel_37.add(scrollPane_13);
		
		table_12 = new JTable();
		scrollPane_13.setViewportView(table_12);
		table_12.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"1\u00B0 Nome do Cliente", "Nome do Animal"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		lblNewLabel_138 = new JLabel("");
		lblNewLabel_138.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_138.setBounds(0, 0, 521, 265);
		panel_37.add(lblNewLabel_138);
		
		panel_34 = new JPanel();
		panel_34.setBackground(Color.ORANGE);
		panel_34.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_34);
		panel_34.setLayout(null);
		
		JScrollPane scrollPane_10 = new JScrollPane();
		scrollPane_10.setBounds(21, 26, 257, 134);
		panel_34.add(scrollPane_10);
		
		table_9 = new JTable();
		scrollPane_10.setViewportView(table_9);
		table_9.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome da Vacina", "Faturamento Total"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		lblNewLabel_141 = new JLabel("");
		lblNewLabel_141.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_141.setBounds(0, 0, 521, 265);
		panel_34.add(lblNewLabel_141);
		
		JLabel label = new JLabel("New label");
		label.setBounds(159, 33, 45, 13);
		panel_34.add(label);
		{
				
				panel = new JPanel();
				panel.setBackground(Color.CYAN);
				panel.setBounds(0, 0, 521, 265);
				layeredPane.add(panel);
				panel.setLayout(null);
				
				lblNewLabel_129 = new JLabel("");
				lblNewLabel_129.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
				lblNewLabel_129.setBounds(0, 0, 521, 265);
				panel.add(lblNewLabel_129);
			}
		
		panel_24 = new JPanel();
		panel_24.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_24);
		panel_24.setBackground(Color.CYAN);
		panel_24.setLayout(null);
		
		table_2 = new JTable();
		table_2.setBounds(266, 16, 0, 0);
		panel_24.add(table_2);
		
		lblNewLabel_76 = new JLabel(" Mostrar uma vacina");
		lblNewLabel_76.setBounds(160, 20, 229, 22);
		lblNewLabel_76.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_76.setFont(new Font("Tahoma", Font.BOLD, 18));
		panel_24.add(lblNewLabel_76);
		
		scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(81, 53, 353, 162);
		panel_24.add(scrollPane_4);
		
		table_3 = new JTable();
		scrollPane_4.setViewportView(table_3);
		table_3.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "Quantidade de ML", "Laborat\u00F3rio", "Data da fab"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Integer.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		textField_67 = new JTextField();
		textField_67.setBounds(54, 25, 96, 19);
		panel_24.add(textField_67);
		textField_67.setColumns(10);
		
		lblNewLabel_90 = new JLabel("Nome");
		lblNewLabel_90.setBounds(10, 28, 45, 13);
		panel_24.add(lblNewLabel_90);
		
		JButton btnNewButton_12 = new JButton("Mostrar");
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table_3.getModel();
				model.setRowCount(0);
				String nomeVacina = textField_67.getText();
				VacinaDAO vdao = new VacinaDAO();
				boolean achou = vdao.getVacina(nomeVacina);
				
				if(achou){
					ArrayList <Vacina> vacinas = vdao.getLista();
					for(int i = 0;i<vacinas.size();i++){
						if(vacinas.get(i).getNome().equals(nomeVacina)){
							Vacina v = new Vacina(nomeVacina, vacinas.get(i).getQtd_ml(), vacinas.get(i).getLab(), vacinas.get(i).getData_fab());
							model.addRow(new Object[] {v.getNome(), v.getQtd_ml(), v.getLab(), v.getData_fab()});
							break;
						}
					}
				}else{
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Esta vacina não está cadastrada!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_12.setBounds(182, 225, 84, 21);
		panel_24.add(btnNewButton_12);
		
		lblNewLabel_119 = new JLabel("");
		lblNewLabel_119.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_119.setBounds(0, 0, 521, 254);
		panel_24.add(lblNewLabel_119);
		panel_20 = new JPanel();
		panel_20.setBackground(Color.RED);
		panel_20.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_20);
		panel_20.setLayout(null);
		
		panel_21 = new JPanel();
		panel_21.setLayout(null);
		panel_21.setBackground(Color.GRAY);
		panel_21.setBounds(0, 0, 521, 265);
		panel_20.add(panel_21);
		
		lblNewLabel_120 = new JLabel("Deletar Vacinação");
		lblNewLabel_120.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_120.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_120.setBounds(10, 26, 512, 23);
		panel_21.add(lblNewLabel_120);
		
		lblNewLabel_121 = new JLabel("CPF Cliente:");
		lblNewLabel_121.setBounds(139, 74, 80, 14);
		panel_21.add(lblNewLabel_121);
		
		lblNewLabel_122 = new JLabel("Nome Animal:");
		lblNewLabel_122.setBounds(139, 99, 80, 14);
		panel_21.add(lblNewLabel_122);
		
		lblNewLabel_123 = new JLabel("Nome Vacina:");
		lblNewLabel_123.setBounds(139, 124, 80, 14);
		panel_21.add(lblNewLabel_123);
		
		lblNewLabel_124 = new JLabel("Data da Aplica\u00E7\u00E3o:");
		lblNewLabel_124.setBounds(139, 149, 116, 14);
		panel_21.add(lblNewLabel_124);
		
		textField_105 = new JTextField();
		textField_105.setColumns(10);
		textField_105.setBounds(246, 71, 51, 20);
		panel_21.add(textField_105);
		
		textField_106 = new JTextField();
		textField_106.setColumns(10);
		textField_106.setBounds(246, 96, 51, 20);
		panel_21.add(textField_106);
		
		textField_107 = new JTextField();
		textField_107.setColumns(10);
		textField_107.setBounds(246, 121, 51, 20);
		panel_21.add(textField_107);
		
		textField_108 = new JTextField();
		textField_108.setColumns(10);
		textField_108.setBounds(246, 146, 51, 20);
		panel_21.add(textField_108);
		
		btnNewButton_11 = new JButton("Deletar");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpfCli = textField_105.getText();
				String nomeAnimal = textField_106.getText();
				String nomeVac = textField_107.getText();
				String dataApli = textField_108.getText();
				TomaDAO tdao = new TomaDAO();
				boolean achou = tdao.getToma(cpfCli, nomeAnimal, nomeVac, dataApli);
				JFrame f = new JFrame();
				if(achou) {
					tdao.deletar(cpfCli, nomeAnimal, nomeVac, dataApli);
					textField_105.setText("");
					textField_106.setText("");
					textField_107.setText("");
					textField_108.setText("");
					JOptionPane.showMessageDialog(f,"Vacinação deletada com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(f,"Esta vacinação não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}

			}
		});
		btnNewButton_11.setBounds(191, 212, 89, 23);
		panel_21.add(btnNewButton_11);
		
		lblNewLabel_118 = new JLabel("");
		lblNewLabel_118.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_118.setBounds(0, 0, 518, 256);
		panel_21.add(lblNewLabel_118);
		
		panel_18 = new JPanel();
		panel_18.setBackground(Color.CYAN);
		panel_18.setBounds(0, 0, 521, 254);
		layeredPane.add(panel_18);
		panel_18.setLayout(null);
		
		panel_19 = new JPanel();
		panel_19.setLayout(null);
		panel_19.setBackground(Color.CYAN);
		panel_19.setBounds(0, 0, 521, 265);
		panel_18.add(panel_19);
		
		lblNewLabel_115 = new JLabel("Deletar Vacina");
		lblNewLabel_115.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_115.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_115.setBounds(0, 32, 501, 13);
		panel_19.add(lblNewLabel_115);
		
		lblNewLabel_116 = new JLabel("Nome:");
		lblNewLabel_116.setBounds(65, 93, 46, 14);
		panel_19.add(lblNewLabel_116);
		
		textField_101 = new JTextField();
		textField_101.setColumns(10);
		textField_101.setBounds(181, 90, 51, 20);
		panel_19.add(textField_101);
		
		btnNewButton_10 = new JButton("Deletar");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = textField_101.getText();
				VacinaDAO vdao = new VacinaDAO();
				boolean achou = vdao.getVacina(nome);
				JFrame f = new JFrame();
				if(achou) {
					vdao.deletar(nome);
					textField_101.setText("");
					JOptionPane.showMessageDialog(f,"Vacina deletada com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(f,"Esta vacina não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_10.setBounds(201, 214, 89, 23);
		panel_19.add(btnNewButton_10);
		
		lblNewLabel_131 = new JLabel("");
		lblNewLabel_131.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_131.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_131.setBounds(0, 0, 517, 253);
		panel_19.add(lblNewLabel_131);
		
		panel_16 = new JPanel();
		panel_16.setBackground(Color.YELLOW);
		panel_16.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_16);
		panel_16.setLayout(null);
		
		panel_17 = new JPanel();
		panel_17.setLayout(null);
		panel_17.setBackground(Color.YELLOW);
		panel_17.setBounds(0, 0, 521, 265);
		panel_16.add(panel_17);
		
		lblNewLabel_105 = new JLabel("Deletar Animal");
		lblNewLabel_105.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_105.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_105.setBounds(0, 34, 521, 14);
		panel_17.add(lblNewLabel_105);
		
		lblNewLabel_106 = new JLabel("CPF Cliente:");
		lblNewLabel_106.setBounds(25, 77, 66, 14);
		panel_17.add(lblNewLabel_106);
		
		textField_92 = new JTextField();
		textField_92.setColumns(10);
		textField_92.setBounds(95, 74, 51, 20);
		panel_17.add(textField_92);
		
		lblNewLabel_107 = new JLabel("Nome:");
		lblNewLabel_107.setBounds(25, 102, 46, 14);
		panel_17.add(lblNewLabel_107);
		
		textField_93 = new JTextField();
		textField_93.setColumns(10);
		textField_93.setBounds(95, 99, 51, 20);
		panel_17.add(textField_93);
		
		btnNewButton_9 = new JButton("Deletar");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpfCli = textField_92.getText();
				String nomeCien = textField_93.getText();
				AnimalDAO adao = new AnimalDAO();
				boolean achou = adao.getAnimal(cpfCli, nomeCien);
				JFrame f = new JFrame();
				if(achou) {
					adao.deletar(cpfCli, nomeCien);
					textField_92.setText("");
					textField_93.setText("");
					JOptionPane.showMessageDialog(f,"Animal deletado com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(f,"Este animal não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_9.setBounds(174, 218, 89, 23);
		panel_17.add(btnNewButton_9);
		
		lblNewLabel_125 = new JLabel("");
		lblNewLabel_125.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_125.setBounds(0, 0, 521, 258);
		panel_17.add(lblNewLabel_125);
		
		panel_14 = new JPanel();
		panel_14.setBackground(Color.ORANGE);
		panel_14.setBounds(0, 0, 521, 254);
		layeredPane.add(panel_14);
		panel_14.setLayout(null);
		
		panel_15 = new JPanel();
		panel_15.setLayout(null);
		panel_15.setBackground(Color.ORANGE);
		panel_15.setBounds(0, 0, 521, 265);
		panel_14.add(panel_15);
		
		lblNewLabel_1 = new JLabel("Deletar Cliente");
		lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNewLabel_1.setBounds(0, 11, 528, 31);
		panel_15.add(lblNewLabel_1);
		
		lblNewLabel_86 = new JLabel("CPF:");
		lblNewLabel_86.setBounds(62, 78, 46, 14);
		panel_15.add(lblNewLabel_86);
		
		textField_75 = new JTextField();
		textField_75.setColumns(10);
		textField_75.setBounds(116, 75, 51, 20);
		panel_15.add(textField_75);
		
		btnDeletar = new JButton("Deletar");
		btnDeletar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpf = textField_75.getText();
				ClienteDAO cdao = new ClienteDAO();
				boolean achou = cdao.getCliente(cpf);
				JFrame f = new JFrame();
				if(achou) {
					cdao.deletar(cpf);
					textField_75.setText("");
					JOptionPane.showMessageDialog(f,"Cliente deletado com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
				}else {
					JOptionPane.showMessageDialog(f,"Este cliente não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnDeletar.setBounds(199, 211, 89, 23);
		panel_15.add(btnDeletar);
		
		lblNewLabel_128 = new JLabel("");
		lblNewLabel_128.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_128.setBounds(0, 0, 519, 256);
		panel_15.add(lblNewLabel_128);
		
		panel_11 = new JPanel();
		panel_11.setBackground(Color.BLUE);
		panel_11.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_11);
		panel_11.setLayout(null);
		
		panel_13 = new JPanel();
		panel_13.setLayout(null);
		panel_13.setBackground(Color.RED);
		panel_13.setBounds(0, 0, 521, 265);
		panel_11.add(panel_13);
		
		lblNewLabel_80 = new JLabel("Alterar Vacinação");
		lblNewLabel_80.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_80.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_80.setBounds(10, 26, 512, 23);
		panel_13.add(lblNewLabel_80);
		
		lblNewLabel_81 = new JLabel("CPF Cliente:");
		lblNewLabel_81.setBounds(139, 74, 80, 14);
		panel_13.add(lblNewLabel_81);
		
		lblNewLabel_82 = new JLabel("Nome Animal:");
		lblNewLabel_82.setBounds(139, 99, 80, 14);
		panel_13.add(lblNewLabel_82);
		
		lblNewLabel_83 = new JLabel("Nome Vacina:");
		lblNewLabel_83.setBounds(139, 124, 80, 14);
		panel_13.add(lblNewLabel_83);
		
		lblNewLabel_84 = new JLabel("Data da Aplica\u00E7\u00E3o:");
		lblNewLabel_84.setBounds(139, 149, 116, 14);
		panel_13.add(lblNewLabel_84);
		
		lblNewLabel_85 = new JLabel("Custo:");
		lblNewLabel_85.setBounds(139, 174, 46, 14);
		panel_13.add(lblNewLabel_85);
		
		textField_70 = new JTextField();
		textField_70.setColumns(10);
		textField_70.setBounds(246, 71, 51, 20);
		panel_13.add(textField_70);
		
		textField_71 = new JTextField();
		textField_71.setColumns(10);
		textField_71.setBounds(246, 96, 51, 20);
		panel_13.add(textField_71);
		
		textField_72 = new JTextField();
		textField_72.setColumns(10);
		textField_72.setBounds(246, 121, 51, 20);
		panel_13.add(textField_72);
		
		textField_73 = new JTextField();
		textField_73.setColumns(10);
		textField_73.setBounds(246, 146, 51, 20);
		panel_13.add(textField_73);
		
		textField_74 = new JTextField();
		textField_74.setColumns(10);
		textField_74.setBounds(246, 174, 51, 20);
		panel_13.add(textField_74);
		
		btnNewButton_8 = new JButton("Alterar");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				    String cpfCli = textField_70.getText();
					String nomeAnimal = textField_71.getText();
					String nomeVac = textField_72.getText();
					String dataApli = textField_73.getText();
					TomaDAO tdao = new TomaDAO();
					boolean achou = tdao.getToma(cpfCli, nomeAnimal, nomeVac, dataApli);
					JFrame f = new JFrame();
					if(achou) {
						Double custo = Double.parseDouble(textField_74.getText());
	                    tdao.alterar(cpfCli, nomeAnimal, nomeVac, dataApli, custo);
	                    textField_70.setText("");
	                    textField_71.setText("");
	                    textField_72.setText("");
	                    textField_73.setText("");
	                    textField_74.setText("");
	                    JOptionPane.showMessageDialog(f,"Vacinação alterada com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
					}else {
						JOptionPane.showMessageDialog(f,"Esta vacinação não existe!","Alert",JOptionPane.WARNING_MESSAGE);
					}
				    
			}
			
		});
		btnNewButton_8.setBounds(191, 212, 89, 23);
		panel_13.add(btnNewButton_8);
		
		lblNewLabel_117 = new JLabel("");
		lblNewLabel_117.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_117.setBounds(0, 0, 522, 267);
		panel_13.add(lblNewLabel_117);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBackground(Color.PINK);
		panel_9.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_9);
		panel_9.setLayout(null);
		
		panel_10 = new JPanel();
		panel_10.setLayout(null);
		panel_10.setBackground(Color.YELLOW);
		panel_10.setBounds(0, 0, 521, 265);
		panel_9.add(panel_10);
		
		lblNewLabel_69 = new JLabel("Alterar Vacina");
		lblNewLabel_69.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_69.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_69.setBounds(0, 32, 501, 13);
		panel_10.add(lblNewLabel_69);
		
		lblNewLabel_70 = new JLabel("Nome:");
		lblNewLabel_70.setBounds(65, 93, 46, 14);
		panel_10.add(lblNewLabel_70);
		
		textField_61 = new JTextField();
		textField_61.setColumns(10);
		textField_61.setBounds(181, 90, 51, 20);
		panel_10.add(textField_61);
		
		lblNewLabel_71 = new JLabel("Quantidade de ml:");
		lblNewLabel_71.setBounds(65, 118, 107, 14);
		panel_10.add(lblNewLabel_71);
		
		textField_62 = new JTextField();
		textField_62.setColumns(10);
		textField_62.setBounds(181, 115, 51, 20);
		panel_10.add(textField_62);
		
		lblNewLabel_72 = new JLabel("Laboratorio:");
		lblNewLabel_72.setBounds(65, 143, 72, 14);
		panel_10.add(lblNewLabel_72);
		
		textField_63 = new JTextField();
		textField_63.setColumns(10);
		textField_63.setBounds(181, 140, 51, 20);
		panel_10.add(textField_63);
		
		lblNewLabel_73 = new JLabel("Data de fabrica\u00E7\u00E3o:");
		lblNewLabel_73.setBounds(65, 168, 95, 14);
		panel_10.add(lblNewLabel_73);
		
		textField_64 = new JTextField();
		textField_64.setColumns(10);
		textField_64.setBounds(181, 171, 51, 20);
		panel_10.add(textField_64);
		
		btnNewButton_6 = new JButton("Alterar");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   	String nome= textField_61.getText();
				   	VacinaDAO vdao = new VacinaDAO();
				   	boolean achou = vdao.getVacina(nome);
				   	JFrame f = new JFrame();
				   	if(achou) {
				   		int qtd_ml = Integer.parseInt (textField_62.getText ());
						String lab = textField_63.getText();
				        String data_fab = textField_64.getText();
						Vacina v = new Vacina(nome, qtd_ml,  lab,  data_fab);
						vdao.alterar(nome,v);
						textField_61.setText("");
						textField_62.setText("");
						textField_63.setText("");
						textField_64.setText("");
						JOptionPane.showMessageDialog(f,"Vacina alterada com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
				   	}else {
				   		JOptionPane.showMessageDialog(f,"Esta vacina não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				   	}
			}
				 
			
		});
		btnNewButton_6.setBounds(201, 214, 89, 23);
		panel_10.add(btnNewButton_6);
		
		lblNewLabel_130 = new JLabel("");
		lblNewLabel_130.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_130.setBounds(0, 0, 518, 255);
		panel_10.add(lblNewLabel_130);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(0, 0, 521, 265);
		layeredPane.add(scrollPane_1);
		
		panel_7 = new JPanel();
		scrollPane_1.setViewportView(panel_7);
		panel_7.setBackground(Color.GREEN);
		panel_7.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 521, 265);
		panel_7.add(scrollPane);
		
		panel_8 = new JPanel();
		scrollPane.setViewportView(panel_8);
		panel_8.setLayout(null);
		panel_8.setBackground(Color.GREEN);
		
		lblNewLabel_59 = new JLabel("Alterar Animal");
		lblNewLabel_59.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_59.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_59.setBounds(0, 34, 521, 14);
		panel_8.add(lblNewLabel_59);
		
		lblNewLabel_60 = new JLabel("CPF Cliente:");
		lblNewLabel_60.setBounds(25, 77, 66, 14);
		panel_8.add(lblNewLabel_60);
		
		textField_52 = new JTextField();
		textField_52.setColumns(10);
		textField_52.setBounds(95, 74, 51, 20);
		panel_8.add(textField_52);
		
		lblNewLabel_61 = new JLabel("Nome:");
		lblNewLabel_61.setBounds(25, 102, 46, 14);
		panel_8.add(lblNewLabel_61);
		
		textField_53 = new JTextField();
		textField_53.setColumns(10);
		textField_53.setBounds(95, 99, 51, 20);
		panel_8.add(textField_53);
		
		lblNewLabel_62 = new JLabel("Especie:");
		lblNewLabel_62.setBounds(25, 133, 46, 14);
		panel_8.add(lblNewLabel_62);
		
		textField_54 = new JTextField();
		textField_54.setColumns(10);
		textField_54.setBounds(95, 130, 51, 20);
		panel_8.add(textField_54);
		
		lblNewLabel_63 = new JLabel("Peso:");
		lblNewLabel_63.setBounds(25, 164, 46, 14);
		panel_8.add(lblNewLabel_63);
		
		textField_55 = new JTextField();
		textField_55.setColumns(10);
		textField_55.setBounds(95, 161, 51, 20);
		panel_8.add(textField_55);
		
		lblNewLabel_64 = new JLabel("Sexo:");
		lblNewLabel_64.setBounds(25, 189, 46, 14);
		panel_8.add(lblNewLabel_64);
		
		textField_56 = new JTextField();
		textField_56.setColumns(10);
		textField_56.setBounds(95, 192, 51, 20);
		panel_8.add(textField_56);
		
		lblNewLabel_65 = new JLabel("Classificação:");
		lblNewLabel_65.setBounds(174, 77, 66, 14);
		panel_8.add(lblNewLabel_65);
		
		textField_57 = new JTextField();
		textField_57.setColumns(10);
		textField_57.setBounds(284, 74, 51, 20);
		panel_8.add(textField_57);
		
		lblNewLabel_66 = new JLabel("Data de  nascimento:");
		lblNewLabel_66.setBounds(174, 102, 117, 14);
		panel_8.add(lblNewLabel_66);
		
		textField_58 = new JTextField();
		textField_58.setColumns(10);
		textField_58.setBounds(284, 99, 51, 20);
		panel_8.add(textField_58);
		
		lblNewLabel_67 = new JLabel("Info adicional:");
		lblNewLabel_67.setBounds(174, 133, 100, 14);
		panel_8.add(lblNewLabel_67);
		
		textField_59 = new JTextField();
		textField_59.setColumns(10);
		textField_59.setBounds(284, 130, 51, 20);
		panel_8.add(textField_59);
		
		lblNewLabel_68 = new JLabel("Alimentação prin:");
		lblNewLabel_68.setBounds(174, 164, 100, 14);
		panel_8.add(lblNewLabel_68);
		
		textField_60 = new JTextField();
		textField_60.setColumns(10);
		textField_60.setBounds(284, 161, 51, 20);
		panel_8.add(textField_60);
		
		btnNewButton_5 = new JButton("Alterar");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					JFrame f = new JFrame();
			        String cpfCli = textField_52.getText();
			        String nomeCien = textField_53.getText();
			        AnimalDAO adao = new AnimalDAO();
			        boolean achou = adao.getAnimal(cpfCli, nomeCien);
			        if(achou) {
			        	String especie = textField_54.getText();
						double peso = Double.parseDouble (textField_55.getText ());
						String sexo = textField_56.getText();
						String classificacao = textField_57.getText();
						String data_nas = textField_58.getText();
						String infoAd  = textField_59.getText();
						String alimentacaoPrin  = textField_60.getText();
						Animal a = new Animal(cpfCli, nomeCien, especie, peso, sexo, classificacao, data_nas, infoAd,alimentacaoPrin);
						adao.alterar(cpfCli,nomeCien, a);
						textField_52.setText("");
						textField_53.setText("");
						textField_54.setText("");
						textField_55.setText("");
						textField_56.setText("");
						textField_57.setText("");
						textField_58.setText("");
						textField_59.setText("");
						textField_60.setText("");
						JOptionPane.showMessageDialog(f,"Animal alterado com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
			        }else {
			        	JOptionPane.showMessageDialog(f,"Este animal não existe!","Alert",JOptionPane.WARNING_MESSAGE);
			        }
			}
		});
		btnNewButton_5.setBounds(174, 218, 89, 23);
		panel_8.add(btnNewButton_5);
		
		lblNewLabel_145 = new JLabel("");
		lblNewLabel_145.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_145.setBounds(0, 0, 521, 263);
		panel_8.add(lblNewLabel_145);
		
		panel_33 = new JPanel();
		panel_33.setLayout(null);
		panel_33.setBackground(Color.RED);
		panel_33.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_33);
		
		lblNewLabel_97 = new JLabel("Alterar Vacinação");
		lblNewLabel_97.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_97.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_97.setBounds(10, 26, 512, 23);
		panel_33.add(lblNewLabel_97);
		
		lblNewLabel_98 = new JLabel("CPF Cliente:");
		lblNewLabel_98.setBounds(139, 74, 80, 14);
		panel_33.add(lblNewLabel_98);
		
		lblNewLabel_99 = new JLabel("Nome Animal:");
		lblNewLabel_99.setBounds(139, 99, 80, 14);
		panel_33.add(lblNewLabel_99);
		
		lblNewLabel_100 = new JLabel("Nome Vacina:");
		lblNewLabel_100.setBounds(139, 124, 80, 14);
		panel_33.add(lblNewLabel_100);
		
		lblNewLabel_101 = new JLabel("Data da Aplicação:");
		lblNewLabel_101.setBounds(139, 149, 116, 14);
		panel_33.add(lblNewLabel_101);
		
		lblNewLabel_102 = new JLabel("Custo:");
		lblNewLabel_102.setBounds(139, 174, 46, 14);
		panel_33.add(lblNewLabel_102);
		
		textField_79 = new JTextField();
		textField_79.setColumns(10);
		textField_79.setBounds(246, 71, 51, 20);
		panel_33.add(textField_79);
		
		textField_80 = new JTextField();
		textField_80.setColumns(10);
		textField_80.setBounds(246, 96, 51, 20);
		panel_33.add(textField_80);
		
		textField_81 = new JTextField();
		textField_81.setColumns(10);
		textField_81.setBounds(246, 121, 51, 20);
		panel_33.add(textField_81);
		
		textField_82 = new JTextField();
		textField_82.setColumns(10);
		textField_82.setBounds(246, 146, 51, 20);
		panel_33.add(textField_82);
		
		textField_83 = new JTextField();
		textField_83.setColumns(10);
		textField_83.setBounds(246, 174, 51, 20);
		panel_33.add(textField_83);
		
		btnNewButton_20 = new JButton("Alterar");
		btnNewButton_20.setBounds(191, 212, 89, 23);
		panel_33.add(btnNewButton_20);
		
		lblNewLabel_142 = new JLabel("");
		lblNewLabel_142.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_142.setBounds(0, 0, 521, 265);
		panel_33.add(lblNewLabel_142);
		
		panel_30 = new JPanel();
		panel_30.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_30);
		panel_30.setBackground(Color.ORANGE);
		panel_30.setLayout(null);
		
		lblNewLabel_127 = new JLabel("Mostrar todas as vacinações");
		lblNewLabel_127.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_127.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_127.setBounds(-55, 11, 685, 28);
		panel_30.add(lblNewLabel_127);
		
		scrollPane_9 = new JScrollPane();
		scrollPane_9.setBounds(29, 49, 433, 160);
		panel_30.add(scrollPane_9);
		
		table_8 = new JTable();
		scrollPane_9.setViewportView(table_8);
		table_8.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF do Cliente", "Nome do Animal", "Nome da Vacina", "Data da aplica\u00E7\u00E3o", "Custo"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, Double.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		lblNewLabel_139 = new JLabel("");
		lblNewLabel_139.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_139.setBounds(0, 0, 521, 265);
		panel_30.add(lblNewLabel_139);
		
		panel_29 = new JPanel();
		panel_29.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_29);
		panel_29.setBackground(Color.PINK);
		panel_29.setLayout(null);
		
		lblNewLabel_126 = new JLabel("Mostrar todas as vacinas");
		lblNewLabel_126.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_126.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_126.setBounds(10, 0, 685, 40);
		panel_29.add(lblNewLabel_126);
		
		scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(34, 50, 461, 169);
		panel_29.add(scrollPane_8);
		
		table_7 = new JTable();
		scrollPane_8.setViewportView(table_7);
		table_7.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "Quantidade de ml", "Laborat\u00F3rio", "Data Fabrica\u00E7\u00E3o"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Integer.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		lblNewLabel_135 = new JLabel("");
		lblNewLabel_135.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_135.setBounds(0, 0, 521, 265);
		panel_29.add(lblNewLabel_135);
		
		panel_27 = new JPanel();
		panel_27.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_27);
		panel_27.setBackground(Color.MAGENTA);
		panel_27.setLayout(null);
		
		lblNewLabel_78 = new JLabel("Mostrar todos os animais");
		lblNewLabel_78.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 18));
		lblNewLabel_78.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_78.setBounds(10, 11, 685, 42);
		panel_27.add(lblNewLabel_78);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(20, 63, 483, 163);
		panel_27.add(scrollPane_6);
		
		table_6 = new JTable();
		scrollPane_6.setViewportView(table_6);
		table_6.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF Cliente", "Nome", "Especie", "Peso", "Sexo", "Classifica\u00E7\u00E3o", "Data Nascimento", "Info adicional", "Alimenta\u00E7\u00E3o Principal"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, Double.class, String.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		lblNewLabel_134 = new JLabel("");
		lblNewLabel_134.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_134.setBounds(0, 0, 521, 254);
		panel_27.add(lblNewLabel_134);
		
		panel_26 = new JPanel();
		panel_26.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_26);
		panel_26.setBackground(Color.YELLOW);
		panel_26.setLayout(null);
		
		panel_28 = new JPanel();
		panel_28.setLayout(null);
		panel_28.setBackground(Color.YELLOW);
		panel_28.setBounds(0, -11, 521, 265);
		panel_26.add(panel_28);
		
		lblNewLabel_79 = new JLabel("Mostrar todos os clientes");
		lblNewLabel_79.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_79.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_79.setBounds(181, 11, 345, 31);
		panel_28.add(lblNewLabel_79);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(21, 48, 483, 196);
		panel_28.add(scrollPane_7);
		
		table_5 = new JTable();
		scrollPane_7.setViewportView(table_5);
		table_5.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "RG", "1\u00B0 Nome", "2\u00B0 Nome", "Sobrenome", "Data de Nascimento", "Telefone", "E-mail", "N\u00B0 Cart\u00E3o", "Logradouro", "N\u00B0", "Bairro", "Complemento", "CEP", "Cidade", "Estado", "Pa\u00EDs"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, Integer.class, String.class, String.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		lblNewLabel_133 = new JLabel("");
		lblNewLabel_133.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_133.setBounds(0, 11, 521, 256);
		panel_28.add(lblNewLabel_133);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.MAGENTA);
		panel_5.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_5);
		panel_5.setLayout(null);
		
		panel_6 = new JPanel();
		panel_6.setLayout(null);
		panel_6.setBackground(Color.MAGENTA);
		panel_6.setBounds(0, 0, 521, 265);
		panel_5.add(panel_6);
		
		lblNewLabel_41 = new JLabel("Alterar Cliente ");
		lblNewLabel_41.setBackground(Color.YELLOW);
		lblNewLabel_41.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_41.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_41.setFont(new Font("Times New Roman", Font.BOLD, 26));
		lblNewLabel_41.setBounds(0, 22, 528, 31);
		panel_6.add(lblNewLabel_41);
		
		lblNewLabel_42 = new JLabel("RG:");
		lblNewLabel_42.setBounds(53, 103, 46, 14);
		panel_6.add(lblNewLabel_42);
		
		lblNewLabel_43 = new JLabel("Nome:");
		lblNewLabel_43.setBounds(53, 136, 85, 14);
		panel_6.add(lblNewLabel_43);
		
		lblNewLabel_44 = new JLabel("Segundo nome:");
		lblNewLabel_44.setBounds(25, 161, 85, 14);
		panel_6.add(lblNewLabel_44);
		
		lblNewLabel_45 = new JLabel("Sobrenome:");
		lblNewLabel_45.setBounds(42, 186, 85, 14);
		panel_6.add(lblNewLabel_45);
		
		lblNewLabel_46 = new JLabel("");
		lblNewLabel_46.setBounds(137, 78, 46, 14);
		panel_6.add(lblNewLabel_46);
		
		lblNewLabel_47 = new JLabel("Data de Nascimento:");
		lblNewLabel_47.setBounds(10, 211, 105, 14);
		panel_6.add(lblNewLabel_47);
		
		lblNewLabel_48 = new JLabel("Telefone:");
		lblNewLabel_48.setBounds(209, 78, 46, 14);
		panel_6.add(lblNewLabel_48);
		
		lblNewLabel_49 = new JLabel("E-mail:");
		lblNewLabel_49.setBounds(209, 103, 46, 14);
		panel_6.add(lblNewLabel_49);
		
		lblNewLabel_50 = new JLabel("N\u00FAmero Cart\u00E3o:");
		lblNewLabel_50.setBounds(178, 128, 77, 14);
		panel_6.add(lblNewLabel_50);
		
		lblNewLabel_51 = new JLabel("Logradouro:");
		lblNewLabel_51.setBounds(190, 158, 65, 14);
		panel_6.add(lblNewLabel_51);
		
		textField_36 = new JTextField();
		textField_36.setColumns(10);
		textField_36.setBounds(116, 161, 51, 20);
		panel_6.add(textField_36);
		
		textField_37 = new JTextField();
		textField_37.setColumns(10);
		textField_37.setBounds(116, 133, 51, 20);
		panel_6.add(textField_37);
		
		textField_38 = new JTextField();
		textField_38.setColumns(10);
		textField_38.setBounds(116, 100, 46, 20);
		panel_6.add(textField_38);
		
		textField_39 = new JTextField();
		textField_39.setColumns(10);
		textField_39.setBounds(116, 211, 51, 20);
		panel_6.add(textField_39);
		
		textField_40 = new JTextField();
		textField_40.setColumns(10);
		textField_40.setBounds(265, 75, 51, 20);
		panel_6.add(textField_40);
		
		textField_41 = new JTextField();
		textField_41.setColumns(10);
		textField_41.setBounds(265, 100, 51, 20);
		panel_6.add(textField_41);
		
		textField_42 = new JTextField();
		textField_42.setColumns(10);
		textField_42.setBounds(265, 125, 51, 20);
		panel_6.add(textField_42);
		
		textField_43 = new JTextField();
		textField_43.setColumns(10);
		textField_43.setBounds(265, 155, 51, 20);
		panel_6.add(textField_43);
		
		textField_44 = new JTextField();
		textField_44.setColumns(10);
		textField_44.setBounds(116, 186, 51, 20);
		panel_6.add(textField_44);
		
		lblNewLabel_52 = new JLabel("Numero:");
		lblNewLabel_52.setBounds(200, 186, 46, 14);
		panel_6.add(lblNewLabel_52);
		
		textField_45 = new JTextField();
		textField_45.setColumns(10);
		textField_45.setBounds(265, 183, 51, 20);
		panel_6.add(textField_45);
		
		lblNewLabel_53 = new JLabel("Bairro:");
		lblNewLabel_53.setBounds(209, 211, 46, 14);
		panel_6.add(lblNewLabel_53);
		
		textField_46 = new JTextField();
		textField_46.setColumns(10);
		textField_46.setBounds(265, 208, 51, 20);
		panel_6.add(textField_46);
		
		lblNewLabel_54 = new JLabel("Complemento:");
		lblNewLabel_54.setBounds(353, 78, 85, 14);
		panel_6.add(lblNewLabel_54);
		
		lblNewLabel_55 = new JLabel("CEP:");
		lblNewLabel_55.setBounds(375, 103, 46, 14);
		panel_6.add(lblNewLabel_55);
		
		lblNewLabel_56 = new JLabel("Cidade:");
		lblNewLabel_56.setBounds(363, 136, 46, 14);
		panel_6.add(lblNewLabel_56);
		
		lblNewLabel_57 = new JLabel("Estado:");
		lblNewLabel_57.setBounds(363, 161, 46, 14);
		panel_6.add(lblNewLabel_57);
		
		lblNewLabel_58 = new JLabel("Pa\u00EDs:");
		lblNewLabel_58.setBounds(363, 186, 46, 14);
		panel_6.add(lblNewLabel_58);
		
		textField_47 = new JTextField();
		textField_47.setColumns(10);
		textField_47.setBounds(431, 75, 51, 20);
		panel_6.add(textField_47);
		
		textField_48 = new JTextField();
		textField_48.setColumns(10);
		textField_48.setBounds(431, 100, 51, 20);
		panel_6.add(textField_48);
		
		textField_49 = new JTextField();
		textField_49.setColumns(10);
		textField_49.setBounds(431, 133, 51, 20);
		panel_6.add(textField_49);
		
		textField_50 = new JTextField();
		textField_50.setColumns(10);
		textField_50.setBounds(431, 158, 51, 20);
		panel_6.add(textField_50);
		
		textField_51 = new JTextField();
		textField_51.setColumns(10);
		textField_51.setBounds(431, 183, 51, 20);
		panel_6.add(textField_51);
		
		btnNewButton_4 = new JButton("Alterar");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpf = textField_35.getText();
				ClienteDAO cdao = new ClienteDAO();
				boolean achou = cdao.getCliente(cpf);
				JFrame f = new JFrame();
				if(achou) {
					String rg = textField_38.getText();
					achou = cdao.getRg(rg);
					if(achou) {
						JOptionPane.showMessageDialog(f,"Este número de RG já existe!","Alert",JOptionPane.WARNING_MESSAGE);
					}else {
						String nCartao = textField_42.getText();
						achou = cdao.getNCartao(nCartao);
						if(achou) {
							JOptionPane.showMessageDialog(f,"Este número de cartão já existe!","Alert",JOptionPane.WARNING_MESSAGE);
						}else {
							String nome = textField_43.getText();
							String segNome = textField_36.getText();
							String sobrenome = textField_44.getText();
							String dataNas = textField_39.getText();
							String telefone = textField_40.getText();
							String email = textField_41.getText();
							String logradouro = textField_43.getText();
							int n= Integer.parseInt(textField_45.getText());
							String bairro = textField_46.getText();
							String complemento = textField_47.getText();
							String CEP = textField_48.getText();
							String cidade = textField_49.getText();
							String estado = textField_50.getText();
							String pais = textField_51.getText();
							
							Cliente c = new Cliente(cpf, rg, nome, segNome, sobrenome, dataNas, telefone, email, nCartao, logradouro, n, bairro, complemento, CEP, cidade, estado, pais);
							
							cdao.alterar(cpf, c);
							textField_35.setText("");
							textField_38.setText("");
							textField_42.setText("");
							textField_43.setText("");
							textField_36.setText("");
							textField_44.setText("");
							textField_39.setText("");
							textField_40.setText("");
							textField_41.setText("");
							textField_43.setText("");
							textField_45.setText("");
							textField_46.setText("");
							textField_47.setText("");
							textField_48.setText("");
							textField_49.setText("");
							textField_50.setText("");
							textField_51.setText("");
							JOptionPane.showMessageDialog(f,"Cliente alterado com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
						}
					}
				}else {
					JOptionPane.showMessageDialog(f,"Este cliente não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_4.setBounds(202, 236, 89, 23);
		panel_6.add(btnNewButton_4);
		
		JLabel lblNewLabel_40 = new JLabel("CPF:");
		lblNewLabel_40.setBounds(53, 78, 46, 14);
		panel_6.add(lblNewLabel_40);
		
		textField_35 = new JTextField();
		textField_35.setBounds(116, 72, 46, 20);
		panel_6.add(textField_35);
		textField_35.setColumns(10);
		
		lblNewLabel_113 = new JLabel("");
		lblNewLabel_113.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_113.setBounds(0, -3, 522, 270);
		panel_6.add(lblNewLabel_113);
		
		panel_25 = new JPanel();
		panel_25.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_25);
		panel_25.setBackground(Color.RED);
		panel_25.setLayout(null);
		
		lblNewLabel_77 = new JLabel("Mostrar uma vacinação");
		lblNewLabel_77.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_77.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_77.setBounds(189, 30, 345, 22);
		panel_25.add(lblNewLabel_77);
		
		textField_69 = new JTextField();
		textField_69.setBounds(102, 10, 96, 19);
		panel_25.add(textField_69);
		textField_69.setColumns(10);
		
		textField_76 = new JTextField();
		textField_76.setBounds(102, 49, 96, 19);
		panel_25.add(textField_76);
		textField_76.setColumns(10);
		
		textField_77 = new JTextField();
		textField_77.setBounds(102, 92, 96, 19);
		panel_25.add(textField_77);
		textField_77.setColumns(10);
		
		textField_78 = new JTextField();
		textField_78.setBounds(102, 133, 96, 19);
		panel_25.add(textField_78);
		textField_78.setColumns(10);
		
		lblNewLabel_92 = new JLabel("CPF Cliente:");
		lblNewLabel_92.setBounds(23, 13, 45, 13);
		panel_25.add(lblNewLabel_92);
		
		lblNewLabel_93 = new JLabel("Nome Animal:");
		lblNewLabel_93.setBounds(23, 52, 45, 13);
		panel_25.add(lblNewLabel_93);
		
		lblNewLabel_94 = new JLabel("Nome Vacina:");
		lblNewLabel_94.setBounds(23, 95, 45, 13);
		panel_25.add(lblNewLabel_94);
		
		lblNewLabel_95 = new JLabel("Data Aplicação:");
		lblNewLabel_95.setBounds(23, 136, 45, 13);
		panel_25.add(lblNewLabel_95);
		
		scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(240, 62, 251, 189);
		panel_25.add(scrollPane_5);
		
		table_4 = new JTable();
		scrollPane_5.setViewportView(table_4);
		table_4.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF do Cliente", "Nome do Animal", "Nome da Vacina", "Data da aplica\u00E7\u00E3o", "Custo"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, Double.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		btnNewButton_18 = new JButton("Mostrar");
		btnNewButton_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table_4.getModel();
				model.setRowCount(0);
				String cpfCli = textField_69.getText();
				String nomeAnimal = textField_76.getText();
				String nomeVacina = textField_77.getText();
				String dataApli = textField_78.getText();
				TomaDAO tdao = new TomaDAO();
				boolean achou = tdao.getToma(cpfCli, nomeAnimal, nomeVacina, dataApli);
				
				if(achou){
					ArrayList <Toma> vacinacoes = tdao.getLista();
					for(int i = 0;i<vacinacoes.size();i++){
						if(vacinacoes.get(i).getAnimal().getCpfCli().equals(cpfCli) && vacinacoes.get(i).getAnimal().getNomeCien().equals(nomeAnimal) && vacinacoes.get(i).getVacina().getNome().equals(nomeVacina) && vacinacoes.get(i).getDataApli().equals(dataApli)){
							Toma t = new Toma(vacinacoes.get(i).getAnimal(), vacinacoes.get(i).getVacina(), dataApli, vacinacoes.get(i).getCusto());
							model.addRow(new Object[] {t.getAnimal().getCpfCli(), t.getAnimal().getNomeCien(), t.getVacina().getNome(), t.getDataApli(), t.getCusto()});
							break;
						}
					}
				}else{
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Esta vacinação não está cadastrada!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_18.setBounds(74, 199, 85, 21);
		panel_25.add(btnNewButton_18);
		
		lblNewLabel_114 = new JLabel("");
		lblNewLabel_114.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_114.setBounds(0, 0, 521, 266);
		panel_25.add(lblNewLabel_114);
		
		panel_23 = new JPanel();
		panel_23.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_23);
		panel_23.setBackground(new Color(255, 200, 0));
		panel_23.setLayout(null);
		
		lblNewLabel_75 = new JLabel("Mostrar  um animal");
		lblNewLabel_75.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_75.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_75.setBounds(-71, 27, 685, 14);
		panel_23.add(lblNewLabel_75);
		
		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(178, 63, 342, 167);
		panel_23.add(scrollPane_3);
		
		table_1 = new JTable();
		scrollPane_3.setViewportView(table_1);
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPFcli", "Nome", "Esp\u00E9cie", "Peso", "Sexo", "Classifica\u00E7\u00E3o", "Data nasc", "InfoAd", "Alimenta\u00E7Prin"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, Double.class, String.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JButton btnNewButton_7 = new JButton("Mostrar");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table_1.getModel();
				model.setRowCount(0);
				String cpf = textField_65.getText();
				String nomeAnimal = textField_66.getText();
				AnimalDAO adao = new AnimalDAO();
				boolean achou = adao.getAnimal(cpf, nomeAnimal);
				
				if(achou){
					ArrayList <Animal> animais = adao.getLista();
					for(int i = 0;i<animais.size();i++){
						if( (animais.get(i).getCpfCli().equals(cpf)) && (animais.get(i).getNomeCien().equals(nomeAnimal)) ){
							Animal a = new Animal(cpf, nomeAnimal, animais.get(i).getEspecie(), animais.get(i).getPeso(), animais.get(i).getSexo(), animais.get(i).getClassificacao(), animais.get(i).getData_nas(), animais.get(i).getInfoAd(), animais.get(i).getAlimentacaoPrin());
							model.addRow(new Object[] {a.getCpfCli(), a.getNomeCien(), a.getEspecie(), a.getPeso(), a.getSexo(), a.getClassificacao(), a.getData_nas(), a.getInfoAd(), a.getAlimentacaoPrin()});
							break;
						}
					}
				}else{
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Este animal não está cadastrado!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_7.setBounds(236, 235, 89, 23);
		panel_23.add(btnNewButton_7);
		
		JLabel lblNewLabel_88 = new JLabel("CPF Cliente:]");
		lblNewLabel_88.setBounds(10, 70, 45, 13);
		panel_23.add(lblNewLabel_88);
		
		JLabel lblNewLabel_89 = new JLabel("Nome Animal:");
		lblNewLabel_89.setBounds(10, 108, 45, 13);
		panel_23.add(lblNewLabel_89);
		
		textField_65 = new JTextField();
		textField_65.setBounds(54, 67, 96, 19);
		panel_23.add(textField_65);
		textField_65.setColumns(10);
		
		textField_66 = new JTextField();
		textField_66.setBounds(54, 105, 96, 19);
		panel_23.add(textField_66);
		textField_66.setColumns(10);
		
		lblNewLabel_136 = new JLabel("");
		lblNewLabel_136.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_136.setBounds(0, 0, 521, 265);
		panel_23.add(lblNewLabel_136);
		
		panel_12 = new JPanel();
		panel_12.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_12);
		panel_12.setBackground(Color.PINK);
		panel_12.setLayout(null);
		
		panel_22 = new JPanel();
		panel_22.setLayout(null);
		panel_22.setBackground(Color.PINK);
		panel_22.setBounds(0, 0, 521, 265);
		panel_12.add(panel_22);
		
		lblNewLabel_74 = new JLabel("Mostrar um cliente");
		lblNewLabel_74.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_74.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_74.setBounds(181, 11, 345, 31);
		panel_22.add(lblNewLabel_74);
		
		textField_68 = new JTextField();
		textField_68.setBounds(92, 11, 96, 19);
		panel_22.add(textField_68);
		textField_68.setColumns(10);
		
		lblNewLabel_91 = new JLabel("CPF:");
		lblNewLabel_91.setBounds(21, 11, 45, 13);
		panel_22.add(lblNewLabel_91);
		
		btnNewButton_16 = new JButton("Mostrar");
		btnNewButton_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.setRowCount(0);
				String cpf = textField_68.getText();
				ClienteDAO cdao = new ClienteDAO();
				boolean achou = cdao.getCliente(cpf);

				if(achou){
					ArrayList <Cliente> clientes = cdao.getLista();
					for(int i = 0;i<clientes.size();i++){
						if(clientes.get(i).getCpf().equals(cpf)){
							Cliente c = new Cliente(cpf, clientes.get(i).getRg(), clientes.get(i).getPrimeiroNome(), clientes.get(i).getSegundoNome(), clientes.get(i).getSobrenome(), clientes.get(i).getData_nas(), clientes.get(i).getFone(), clientes.get(i).getEmail(), clientes.get(i).getnCartao(), clientes.get(i).getLog(), clientes.get(i).getN(), clientes.get(i).getBairro(), clientes.get(i).getComplemento(), clientes.get(i).getCep(), clientes.get(i).getCidade(), clientes.get(i).getEstado(), clientes.get(i).getPais());
							model.addRow(new Object[] {c.getCpf(), c.getRg(), c.getPrimeiroNome(), c.getSegundoNome(), c.getSobrenome(), c.getData_nas(), c.getFone(), c.getEmail(), c.getnCartao(), c.getLog(), c.getN(), c.getBairro(), c.getComplemento(), c.getCep(), c.getCidade(), c.getEstado(), c.getPais()});
							break;
						}
					}
				}else{
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Este cliente não está cadastrado!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_16.setBounds(195, 234, 85, 21);
		panel_22.add(btnNewButton_16);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(21, 43, 478, 179);
		panel_22.add(scrollPane_2);
		
		table = new JTable();
		scrollPane_2.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"CPF", "RG", "1\u00B0 Nome", "2\u00B0 Nome", "Sobrenome", "Data de Nascimento", "Telefone", "E-mail", "N\u00B0 Cart\u00E3o", "Logradouro", "N\u00B0", "Bairro", "Complemento", "CEP", "Cidade", "Estado", "Pa\u00EDs"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, Integer.class, String.class, String.class, String.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		lblNewLabel_132 = new JLabel("");
		lblNewLabel_132.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_132.setBounds(0, 0, 519, 257);
		panel_22.add(lblNewLabel_132);
		
		panel_4 = new JPanel();
		panel_4.setBackground(Color.GRAY);
		panel_4.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_4);
		panel_4.setLayout(null);
		
		lblNewLabel_34 = new JLabel("Cadastrar Vacinação");
		lblNewLabel_34.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_34.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_34.setBounds(10, 26, 512, 23);
		panel_4.add(lblNewLabel_34);
		
		lblNewLabel_35 = new JLabel("CPF Cliente:");
		lblNewLabel_35.setBounds(139, 74, 80, 14);
		panel_4.add(lblNewLabel_35);
		
		lblNewLabel_36 = new JLabel("Nome Animal:");
		lblNewLabel_36.setBounds(139, 99, 80, 14);
		panel_4.add(lblNewLabel_36);
		
		lblNewLabel_37 = new JLabel("Nome Vacina:");
		lblNewLabel_37.setBounds(139, 124, 80, 14);
		panel_4.add(lblNewLabel_37);
		
		lblNewLabel_38 = new JLabel("Data da Aplica\u00E7\u00E3o:");
		lblNewLabel_38.setBounds(139, 149, 116, 14);
		panel_4.add(lblNewLabel_38);
		
		lblNewLabel_39 = new JLabel("Custo:");
		lblNewLabel_39.setBounds(139, 174, 46, 14);
		panel_4.add(lblNewLabel_39);
		
		textField_30 = new JTextField();
		textField_30.setColumns(10);
		textField_30.setBounds(246, 71, 51, 20);
		panel_4.add(textField_30);
		
		textField_31 = new JTextField();
		textField_31.setColumns(10);
		textField_31.setBounds(246, 96, 51, 20);
		panel_4.add(textField_31);
		
		textField_32 = new JTextField();
		textField_32.setColumns(10);
		textField_32.setBounds(246, 121, 51, 20);
		panel_4.add(textField_32);
		
		textField_33 = new JTextField();
		textField_33.setColumns(10);
		textField_33.setBounds(246, 146, 51, 20);
		panel_4.add(textField_33);
		
		textField_34 = new JTextField();
		textField_34.setColumns(10);
		textField_34.setBounds(246, 174, 51, 20);
		panel_4.add(textField_34);
		
		btnNewButton_3 = new JButton("Cadastrar");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpfCli = textField_30.getText();
				String nome = textField_31.getText();
				AnimalDAO adao = new AnimalDAO();
				boolean achou = adao.getAnimal(cpfCli, nome);
				JFrame f = new JFrame();
				if(achou) {
					String nomeVac = textField_32.getText();
					VacinaDAO vdao = new VacinaDAO();
					achou = vdao.getVacina(nomeVac);
					if(achou) {
						String dataApli = textField_33.getText();
						TomaDAO tdao = new TomaDAO();
						achou = tdao.getToma(cpfCli, nome, nomeVac, dataApli);
						if(achou) {
							JOptionPane.showMessageDialog(f,"Esta vacinação já existe!","Alert",JOptionPane.WARNING_MESSAGE);
						}else {
							double custo = Double.parseDouble(textField_34.getText());
							ArrayList <Animal> animais = adao.getLista();
							ArrayList <Vacina> vacinas = vdao.getLista();
							int i;
							int ii;
							
							for(i=0; i<animais.size();i++) {
								if( (animais.get(i).getCpfCli().equals(cpfCli)) && (animais.get(i).getNomeCien().equals(nome)) ) {
									achou = true;
									break;
								}
							}
							Animal a = animais.get(i);
							
							for(ii=0; ii<vacinas.size();ii++) {
								if(vacinas.get(ii).getNome().equals(nomeVac)) {
									achou = true;
									break;
								}
							}
							Vacina v = vacinas.get(ii);
							
							tdao.inserir(a, v, dataApli, custo);
							textField_30.setText("");
							textField_31.setText("");
							textField_32.setText("");
							textField_33.setText("");
							textField_34.setText("");
							JOptionPane.showMessageDialog(f,"Vacinação cadastrada com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
						}
					}else {
						JOptionPane.showMessageDialog(f,"Esta vacina não existe!","Alert",JOptionPane.WARNING_MESSAGE);
					}
				}else {
					JOptionPane.showMessageDialog(f,"Este animal não existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_3.setBounds(191, 212, 106, 23);
		panel_4.add(btnNewButton_3);
		
		JLabel lblNewLabel_112 = new JLabel("New label");
		lblNewLabel_112.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_112.setBounds(0, 0, 522, 266);
		panel_4.add(lblNewLabel_112);
		
		panel_3 = new JPanel();
		panel_3.setBackground(Color.YELLOW);
		panel_3.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_3);
		panel_3.setLayout(null);
		
		lblNewLabel_29 = new JLabel("Cadastrar Vacina");
		lblNewLabel_29.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_29.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_29.setBounds(0, 32, 501, 13);
		panel_3.add(lblNewLabel_29);
		
		lblNewLabel_30 = new JLabel("Nome:");
		lblNewLabel_30.setBounds(65, 93, 46, 14);
		panel_3.add(lblNewLabel_30);
		
		textField_26 = new JTextField();
		textField_26.setColumns(10);
		textField_26.setBounds(181, 90, 51, 20);
		panel_3.add(textField_26);
		
		lblNewLabel_31 = new JLabel("Quantidade de ml:");
		lblNewLabel_31.setBounds(65, 118, 107, 14);
		panel_3.add(lblNewLabel_31);
		
		textField_27 = new JTextField();
		textField_27.setColumns(10);
		textField_27.setBounds(181, 115, 51, 20);
		panel_3.add(textField_27);
		
		lblNewLabel_32 = new JLabel("Laboratorio:");
		lblNewLabel_32.setBounds(65, 143, 72, 14);
		panel_3.add(lblNewLabel_32);
		
		textField_28 = new JTextField();
		textField_28.setColumns(10);
		textField_28.setBounds(181, 140, 51, 20);
		panel_3.add(textField_28);
		
		lblNewLabel_33 = new JLabel("Data de fabrica\u00E7\u00E3o:");
		lblNewLabel_33.setBounds(65, 168, 95, 14);
		panel_3.add(lblNewLabel_33);
		
		textField_29 = new JTextField();
		textField_29.setColumns(10);
		textField_29.setBounds(181, 171, 51, 20);
		panel_3.add(textField_29);
		
		btnNewButton_2 = new JButton("Cadastrar");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = textField_26.getText();
				VacinaDAO vdao = new VacinaDAO();
				boolean achou = vdao.getVacina(nome);
				JFrame f = new JFrame();
				if(achou) {
					JOptionPane.showMessageDialog(f,"Esta vacina já existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}else {
					int qtdml = Integer.parseInt(textField_27.getText());
					String lab = textField_28.getText();
					String data_fab = textField_29.getText();
					Vacina v = new Vacina(nome, qtdml, lab, data_fab);
					vdao.inserir(v);
					textField_26.setText("");
					textField_27.setText("");
					textField_28.setText("");
					textField_29.setText("");
					JOptionPane.showMessageDialog(f,"Vacina cadastrada com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_2.setBounds(201, 214, 107, 23);
		panel_3.add(btnNewButton_2);
		
		JLabel lblNewLabel_111 = new JLabel("");
		lblNewLabel_111.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_111.setBounds(0, 0, 522, 266);
		panel_3.add(lblNewLabel_111);
		
		panel_2 = new JPanel();
		panel_2.setBackground(Color.PINK);
		panel_2.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_2);
		panel_2.setLayout(null);
		
		lblNewLabel_19 = new JLabel("Cadastrar Animal");
		lblNewLabel_19.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_19.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_19.setBounds(0, 34, 521, 14);
		panel_2.add(lblNewLabel_19);
		
		lblNewLabel_20 = new JLabel("CPF Cliente:");
		lblNewLabel_20.setBounds(25, 77, 66, 14);
		panel_2.add(lblNewLabel_20);
		
		textField_17 = new JTextField();
		textField_17.setColumns(10);
		textField_17.setBounds(95, 74, 51, 20);
		panel_2.add(textField_17);
		
		lblNewLabel_21 = new JLabel("Nome:");
		lblNewLabel_21.setBounds(25, 102, 46, 14);
		panel_2.add(lblNewLabel_21);
		
		textField_18 = new JTextField();
		textField_18.setColumns(10);
		textField_18.setBounds(95, 99, 51, 20);
		panel_2.add(textField_18);
		
		lblNewLabel_22 = new JLabel("Especie:");
		lblNewLabel_22.setBounds(25, 133, 46, 14);
		panel_2.add(lblNewLabel_22);
		
		textField_19 = new JTextField();
		textField_19.setColumns(10);
		textField_19.setBounds(95, 130, 51, 20);
		panel_2.add(textField_19);
		
		lblNewLabel_23 = new JLabel("Peso:");
		lblNewLabel_23.setBounds(25, 164, 46, 14);
		panel_2.add(lblNewLabel_23);
		
		textField_20 = new JTextField();
		textField_20.setColumns(10);
		textField_20.setBounds(95, 161, 51, 20);
		panel_2.add(textField_20);
		
		lblNewLabel_24 = new JLabel("Sexo:");
		lblNewLabel_24.setBounds(25, 189, 46, 14);
		panel_2.add(lblNewLabel_24);
		
		textField_21 = new JTextField();
		textField_21.setColumns(10);
		textField_21.setBounds(95, 192, 51, 20);
		panel_2.add(textField_21);
		
		lblNewLabel_25 = new JLabel("Classifica\u00E7\u00E3o:");
		lblNewLabel_25.setBounds(174, 77, 66, 14);
		panel_2.add(lblNewLabel_25);
		
		textField_22 = new JTextField();
		textField_22.setColumns(10);
		textField_22.setBounds(284, 74, 51, 20);
		panel_2.add(textField_22);
		
		lblNewLabel_26 = new JLabel("Data de  nascimento:");
		lblNewLabel_26.setBounds(174, 102, 117, 14);
		panel_2.add(lblNewLabel_26);
		
		textField_23 = new JTextField();
		textField_23.setColumns(10);
		textField_23.setBounds(284, 99, 51, 20);
		panel_2.add(textField_23);
		
		lblNewLabel_27 = new JLabel("Info adicional:");
		lblNewLabel_27.setBounds(174, 133, 100, 14);
		panel_2.add(lblNewLabel_27);
		
		textField_24 = new JTextField();
		textField_24.setColumns(10);
		textField_24.setBounds(284, 130, 51, 20);
		panel_2.add(textField_24);
		
		lblNewLabel_28 = new JLabel("Alimenta\u00E7\u00E3o prin:");
		lblNewLabel_28.setBounds(174, 164, 100, 14);
		panel_2.add(lblNewLabel_28);
		
		textField_25 = new JTextField();
		textField_25.setColumns(10);
		textField_25.setBounds(284, 161, 51, 20);
		panel_2.add(textField_25);
		
		btnNewButton_1 = new JButton("Cadastrar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpfCli = textField_17.getText();
				String nome = textField_18.getText();
				AnimalDAO adao = new AnimalDAO();
				boolean achou = adao.getAnimal(cpfCli, nome);
				if(achou) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Este animal já existe!","Alert",JOptionPane.WARNING_MESSAGE);
				}else {
					String especie = textField_19.getText();
					double peso = Double.parseDouble(textField_20.getText());
					String sexo = textField_21.getText();
					String classificacao = textField_22.getText();
					String dataNas = textField_23.getText();
					String infoAd = textField_24.getText();
					String alimentacaoPrin = textField_25.getText();
					Animal a = new Animal(cpfCli, nome, especie, peso, sexo, classificacao, dataNas, infoAd, alimentacaoPrin);
					adao.inserir(a);
					textField_17.setText("");
					textField_18.setText("");
					textField_19.setText("");
					textField_20.setText("");
					textField_21.setText("");
					textField_22.setText("");
					textField_23.setText("");
					textField_24.setText("");
					textField_25.setText("");
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Animal cadastrado com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		btnNewButton_1.setBounds(174, 218, 117, 23); 
		panel_2.add(btnNewButton_1);
		
		JLabel lblNewLabel_110 = new JLabel("");
		lblNewLabel_110.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_110.setBounds(0, 0, 521, 265);
		panel_2.add(lblNewLabel_110);
		
		panel_1 = new JPanel();
		panel_1.setBackground(Color.MAGENTA);
		panel_1.setBounds(0, 0, 521, 265);
		layeredPane.add(panel_1);
		panel_1.setLayout(null);
		
		lblNewLabel_87 = new JLabel("Cadastrar Cliente ");
		lblNewLabel_87.setBounds(0, 11, 528, 31);
		lblNewLabel_87.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_87.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_87.setFont(new Font("Times New Roman", Font.BOLD, 26));
		panel_1.add(lblNewLabel_87);
		
		lblNewLabel = new JLabel("CPF:");
		lblNewLabel.setBounds(62, 78, 46, 14);
		panel_1.add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("RG:");
		lblNewLabel_2.setBounds(62, 111, 46, 14);
		panel_1.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Nome:");
		lblNewLabel_3.setBounds(53, 136, 85, 14);
		panel_1.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("Segundo nome:");
		lblNewLabel_4.setBounds(25, 161, 85, 14);
		panel_1.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("Sobrenome:");
		lblNewLabel_5.setBounds(42, 186, 85, 14);
		panel_1.add(lblNewLabel_5);
		
		lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setBounds(137, 78, 46, 14);
		panel_1.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("Data de Nascimento:");
		lblNewLabel_7.setBounds(10, 211, 105, 14);
		panel_1.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Telefone:");
		lblNewLabel_8.setBounds(209, 78, 46, 14);
		panel_1.add(lblNewLabel_8);
		
		lblNewLabel_9 = new JLabel("E-mail:");
		lblNewLabel_9.setBounds(209, 103, 46, 14);
		panel_1.add(lblNewLabel_9);
		
		lblNewLabel_10 = new JLabel("N\u00FAmero Cart\u00E3o:");
		lblNewLabel_10.setBounds(178, 128, 77, 14);
		panel_1.add(lblNewLabel_10);
		
		lblNewLabel_11 = new JLabel("Logradouro:");
		lblNewLabel_11.setBounds(190, 158, 65, 14);
		panel_1.add(lblNewLabel_11);
		
		textField = new JTextField();
		textField.setBounds(116, 75, 51, 20);
		panel_1.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(116, 161, 51, 20);
		textField_1.setColumns(10);
		panel_1.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setBounds(116, 133, 51, 20);
		textField_2.setColumns(10);
		panel_1.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setBounds(116, 108, 51, 20);
		textField_3.setColumns(10);
		panel_1.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setBounds(116, 211, 51, 20);
		textField_4.setColumns(10);
		panel_1.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setBounds(265, 75, 51, 20);
		textField_5.setColumns(10);
		panel_1.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setBounds(265, 100, 51, 20);
		textField_6.setColumns(10);
		panel_1.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setBounds(265, 125, 51, 20);
		textField_7.setColumns(10);
		panel_1.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setBounds(265, 155, 51, 20);
		textField_8.setColumns(10);
		panel_1.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setBounds(116, 186, 51, 20);
		panel_1.add(textField_9);
		textField_9.setColumns(10);
		
		JLabel lblNewLabel_12 = new JLabel("Numero:");
		lblNewLabel_12.setBounds(200, 186, 46, 14);
		panel_1.add(lblNewLabel_12);
		
		textField_10 = new JTextField();
		textField_10.setBounds(265, 183, 51, 20);
		textField_10.setColumns(10);
		panel_1.add(textField_10);
		
		JLabel lblNewLabel_13 = new JLabel("Bairro:");
		lblNewLabel_13.setBounds(209, 211, 46, 14);
		panel_1.add(lblNewLabel_13);
		
		textField_11 = new JTextField();
		textField_11.setBounds(265, 208, 51, 20);
		textField_11.setColumns(10);
		panel_1.add(textField_11);
		
		lblNewLabel_14 = new JLabel("Complemento:");
		lblNewLabel_14.setBounds(353, 78, 85, 14);
		panel_1.add(lblNewLabel_14);
		
		lblNewLabel_15 = new JLabel("CEP:");
		lblNewLabel_15.setBounds(375, 103, 46, 14);
		panel_1.add(lblNewLabel_15);
		
		lblNewLabel_16 = new JLabel("Cidade:");
		lblNewLabel_16.setBounds(363, 136, 46, 14);
		panel_1.add(lblNewLabel_16);
		
		lblNewLabel_17 = new JLabel("Estado:");
		lblNewLabel_17.setBounds(363, 161, 46, 14);
		panel_1.add(lblNewLabel_17);
		
		lblNewLabel_18 = new JLabel("Pa\u00EDs:");
		lblNewLabel_18.setBounds(363, 186, 46, 14);
		panel_1.add(lblNewLabel_18);
		
		textField_12 = new JTextField();
		textField_12.setBounds(431, 75, 51, 20);
		textField_12.setColumns(10);
		panel_1.add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setBounds(431, 100, 51, 20);
		textField_13.setColumns(10);
		panel_1.add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setBounds(431, 133, 51, 20);
		textField_14.setColumns(10);
		panel_1.add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setBounds(431, 158, 51, 20);
		textField_15.setColumns(10);
		panel_1.add(textField_15);
		
		textField_16 = new JTextField();
		textField_16.setBounds(431, 183, 51, 20);
		textField_16.setColumns(10);
		panel_1.add(textField_16);
		
		JButton btnNewButton = new JButton("Cadastrar");
		btnNewButton.setBounds(209, 231, 114, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpf = textField.getText();
				ClienteDAO cdao = new ClienteDAO();
				boolean achou = cdao.getCliente(cpf);
				if(achou) {
					JFrame f = new JFrame();
					JOptionPane.showMessageDialog(f,"Este cliente já está cadastrado!","Alert",JOptionPane.WARNING_MESSAGE);    
				}else {
					String rg = textField_3.getText();
					achou = cdao.getRg(rg);
					if(achou) {
						JFrame f = new JFrame();
						JOptionPane.showMessageDialog(f,"Este número de RG já está cadastrado!","Alert",JOptionPane.WARNING_MESSAGE);   
					}else {
						String nCartao = textField_7.getText();
						achou = cdao.getNCartao(nCartao);
						if(achou) {
							JFrame f = new JFrame();
							JOptionPane.showMessageDialog(f,"Este número de cartão já está cadastrado!","Alert",JOptionPane.WARNING_MESSAGE);
						}else {
							String primeiroNome = textField_2.getText();
							String segundoNome = textField_1.getText();
							String sobrenome = textField_9.getText();
							String data_nas = textField_4.getText();
							String fone = textField_5.getText();
							String email = textField_6.getText();
							String log = textField_8.getText();
							int n = Integer.parseInt(textField_10.getText());
							String bairro = textField_11.getText();
							String complemento = textField_12.getText();
							String cep = textField_13.getText();
							String cidade = textField_14.getText();
							String estado = textField_15.getText();
							String pais = textField_16.getText();
							Cliente c = new Cliente(cpf,rg,primeiroNome,segundoNome,sobrenome,data_nas,fone,email,nCartao,log,n,bairro,complemento,cep,cidade,estado,pais);
							cdao.inserir(c);
							textField.setText("");
							textField_3.setText("");
							textField_2.setText("");
							textField_1.setText("");
							textField_9.setText("");
							textField_4.setText("");
							textField_5.setText("");
							textField_6.setText("");
							textField_7.setText("");
							textField_8.setText("");
							textField_10.setText("");
							textField_11.setText("");
							textField_12.setText("");
							textField_13.setText("");
							textField_14.setText("");
							textField_15.setText("");
							textField_16.setText("");
							JFrame f = new JFrame();
							JOptionPane.showMessageDialog(f,"Cliente cadastrado com sucesso!","Alert",JOptionPane.WARNING_MESSAGE);    
						}
					}
				}
			}
			
		});
		panel_1.add(btnNewButton);
		
		JLabel lblNewLabel_109 = new JLabel("");
		lblNewLabel_109.setIcon(new ImageIcon(MenuParceriaAnimal1.class.getResource("/img/imagem 1.jpg")));
		lblNewLabel_109.setBounds(0, 0, 528, 266);
		panel_1.add(lblNewLabel_109);
}	
}