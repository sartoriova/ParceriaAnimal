package bean;

public class FaturamentoVacina {
	private String nomeVac;
	private double faturamento;
	
	public FaturamentoVacina(String nomeVac, double faturamento) {
		super();
		this.nomeVac = nomeVac;
		this.faturamento = faturamento;
	}

	public String getNomeVac() {
		return nomeVac;
	}

	public double getFaturamento() {
		return faturamento;
	}
}
