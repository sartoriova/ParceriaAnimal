package bean;

public class CustoVacina {
	private String nomeVac;
	private double custo;
	
	public CustoVacina(String nomeVac, double custo) {
		super();
		this.nomeVac = nomeVac;
		this.custo = custo;
	}

	public String getNomeVac() {
		return nomeVac;
	}

	public double getCusto() {
		return custo;
	} 
}
