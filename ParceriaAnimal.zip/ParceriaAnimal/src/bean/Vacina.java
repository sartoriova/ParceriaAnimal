package bean;

public class Vacina {
	private String nome;
	private int qtd_ml;
	private String lab;
	private String data_fab;
	
	public Vacina(String nome, int qtd_ml, String lab, String data_fab) {
		super();
		this.nome = nome;
		this.qtd_ml = qtd_ml;
		this.lab = lab;
		this.data_fab = data_fab;
	}

	public Vacina() {
		// TODO Auto-generated constructor stub
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getQtd_ml() {
		return qtd_ml;
	}

	public void setQtd_ml(int qtd_ml) {
		this.qtd_ml = qtd_ml;
	}

	public String getLab() {
		return lab;
	}

	public void setLab(String lab) {
		this.lab = lab;
	}

	public String getData_fab() {
		return data_fab;
	}

	public void setData_fab(String data_fab) {
		this.data_fab = data_fab;
	}

	@Override
	public String toString() {
		return "Vacina [nome=" + nome + ", qtd_ml=" + qtd_ml + ", lab=" + lab + ", data_fab=" + data_fab + "]";
	}
}
