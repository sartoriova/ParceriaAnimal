package bean;

public class ClienteAnimal {
	private String nomeCliente;
	private String nomeAnimal;
	
	public ClienteAnimal(String nomeCliente, String nomeAnimal) {
		super();
		this.nomeCliente = nomeCliente;
		this.nomeAnimal = nomeAnimal;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public String getNomeAnimal() {
		return nomeAnimal;
	}
}
