package bean;

public class AnimalVacina {
	private String nomeAnimal;
	private String nomeVacina;
	
	public AnimalVacina(String nomeAnimal, String nomeVacina) {
		super();
		this.nomeAnimal = nomeAnimal;
		this.nomeVacina = nomeVacina;
	}

	public String getNomeAnimal() {
		return nomeAnimal;
	}

	public String getNomeVacina() {
		return nomeVacina;
	}
}
