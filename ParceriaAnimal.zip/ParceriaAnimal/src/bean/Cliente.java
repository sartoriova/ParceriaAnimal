package bean;

public class Cliente {
	private String cpf;
	private String rg;
	private String primeiroNome;
	private String segundoNome;
	private String sobrenome;
	private String data_nas;
	private String fone;
	private String email;
	private String nCartao;
	private String log;
	private int n;
	private String bairro;
	private String complemento;
	private String cep;
	private String cidade;
	private String estado;
	private String pais;
	
	public Cliente(String cpf, String rg, String primeiroNome, String segundoNome, String sobrenome, String data_nas,
			String fone, String email, String nCartao, String log, int n, String bairro, String complemento, String cep,
			String cidade, String estado, String pais) {
		super();
		this.cpf = cpf;
		this.rg = rg;
		this.primeiroNome = primeiroNome;
		this.segundoNome = segundoNome;
		this.sobrenome = sobrenome;
		this.data_nas = data_nas;
		this.fone = fone;
		this.email = email;
		this.nCartao = nCartao;
		this.log = log;
		this.n = n;
		this.bairro = bairro;
		this.complemento = complemento;
		this.cep = cep;
		this.cidade = cidade;
		this.estado = estado;
		this.pais = pais;
	}

	public Cliente() {
		// TODO Auto-generated constructor stub
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public String getPrimeiroNome() {
		return primeiroNome;
	}

	public void setPrimeiroNome(String primeiroNome) {
		this.primeiroNome = primeiroNome;
	}

	public String getSegundoNome() {
		return segundoNome;
	}

	public void setSegundoNome(String segundoNome) {
		this.segundoNome = segundoNome;
	}

	public String getSobrenome() {
		return sobrenome;
	}

	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public String getData_nas() {
		return data_nas;
	}

	public void setData_nas(String data_nas) {
		this.data_nas = data_nas;
	}

	public String getFone() {
		return fone;
	}

	public void setFone(String fone) {
		this.fone = fone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getnCartao() {
		return nCartao;
	}

	public void setnCartao(String nCartao) {
		this.nCartao = nCartao;
	}

	public String getLog() {
		return log;
	}

	public void setLog(String log) {
		this.log = log;
	}

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getComplemento() {
		return complemento;
	}

	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	@Override
	public String toString() {
		return "Cliente [cpf=" + cpf + ", rg=" + rg + ", primeiroNome=" + primeiroNome + ", segundoNome=" + segundoNome
				+ ", sobrenome=" + sobrenome + ", data_nas=" + data_nas + ", fone=" + fone + ", email=" + email
				+ ", nCartao=" + nCartao + ", log=" + log + ", n=" + n + ", bairro=" + bairro + ", complemento="
				+ complemento + ", cep=" + cep + ", cidade=" + cidade + ", estado=" + estado + ", pais=" + pais + "]";
	}
}