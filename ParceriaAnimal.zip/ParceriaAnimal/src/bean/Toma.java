package bean;

public class Toma {
	private Animal animal;
	private Vacina vacina;
	private String dataApli;
	private double custo;
	
	public Toma(Animal animal, Vacina vacina, String dataApli, double custo) {
		super();
		this.animal = animal;
		this.vacina = vacina;
		this.dataApli = dataApli;
		this.custo = custo;
	}

	public Toma() {
		// TODO Auto-generated constructor stub
	}

	public Animal getAnimal() {
		return animal;
	}

	public void setAnimal(Animal animal) {
		this.animal = animal;
	}

	public Vacina getVacina() {
		return vacina;
	}

	public void setVacina(Vacina vacina) {
		this.vacina = vacina;
	}

	public String getDataApli() {
		return dataApli;
	}

	public void setDataApli(String dataApli) {
		this.dataApli = dataApli;
	}

	public double getCusto() {
		return custo;
	}

	public void setCusto(double custo) {
		this.custo = custo;
	}

	@Override
	public String toString() {
		return "Toma [animal=" + animal + ", vacina=" + vacina + ", dataApli=" + dataApli + ", custo=" + custo + "]";
	}
}
