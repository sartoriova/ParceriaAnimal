package bean;

public class ClientesAnimais {
	private String nomeCliente;
	private String nomeAnimal;
	
	public ClientesAnimais(String nomeCliente, String nomeAnimal) {
		super();
		this.nomeCliente = nomeCliente;
		this.nomeAnimal = nomeAnimal;
	}

	public String getNomeCliente() {
		return nomeCliente;
	}

	public String getNomeAnimal() {
		return nomeAnimal;
	}
}
