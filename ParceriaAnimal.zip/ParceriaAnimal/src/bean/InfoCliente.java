package bean;

public class InfoCliente {
	private String nomeAnimal;
	private String infoAd;
	
	public InfoCliente(String nomeAnimal, String infoAd) {
		super();
		this.nomeAnimal = nomeAnimal;
		this.infoAd = infoAd;
	}

	public String getNomeAnimal() {
		return nomeAnimal;
	}

	public String getInfoAd() {
		return infoAd;
	}
}
