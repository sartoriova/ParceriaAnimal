package bean;

public class Animal {
	private String cpfCli;
	private String nomeCien;
	private String especie;
	private double peso;
	private String sexo;
	private String classificacao;
	private String data_nas;
	private String infoAd;
	private String alimentacaoPrin;
	
	public Animal(String cpfCli, String nomeCien, String especie, double peso, String sexo, String classificacao,
			String data_nas, String infoAd, String alimentacaoPrin) {
		super();
		this.cpfCli = cpfCli;
		this.nomeCien = nomeCien;
		this.especie = especie;
		this.peso = peso;
		this.sexo = sexo;
		this.classificacao = classificacao;
		this.data_nas = data_nas;
		this.infoAd = infoAd;
		this.alimentacaoPrin = alimentacaoPrin;
	}

	public Animal() {
		// TODO Auto-generated constructor stub
	}

	public String getCpfCli() {
		return cpfCli;
	}

	public void setCpfCli(String cpfCli) {
		this.cpfCli = cpfCli;
	}

	public String getNomeCien() {
		return nomeCien;
	}

	public void setNomeCien(String nomeCien) {
		this.nomeCien = nomeCien;
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getClassificacao() {
		return classificacao;
	}

	public void setClassificacao(String classificacao) {
		this.classificacao = classificacao;
	}

	public String getData_nas() {
		return data_nas;
	}

	public void setData_nas(String data_nas) {
		this.data_nas = data_nas;
	}

	public String getInfoAd() {
		return infoAd;
	}

	public void setInfoAd(String infoAd) {
		this.infoAd = infoAd;
	}

	public String getAlimentacaoPrin() {
		return alimentacaoPrin;
	}

	public void setAlimentacaoPrin(String alimentacaoPrin) {
		this.alimentacaoPrin = alimentacaoPrin;
	}

	@Override
	public String toString() {
		return "Animal [cpfCli=" + cpfCli + ", nomeCien=" + nomeCien + ", especie=" + especie + ", peso=" + peso
				+ ", sexo=" + sexo + ", classificacao=" + classificacao + ", data_nas=" + data_nas + ", infoAd="
				+ infoAd + ", alimentacaoPrin=" + alimentacaoPrin + "]";
	}
}


